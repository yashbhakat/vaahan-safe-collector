import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { chromium } from 'playwright';
import { BREAKDOWNS, SOURCE_URL, VEHICLE_SEGMENTS } from './catalog.mjs';
import { estimateJob } from './estimator.mjs';

const ROOT = process.cwd();
const JOBS_DIR = path.join(ROOT, 'data', 'jobs');
const USAGE_FILE = path.join(ROOT, 'data', 'daily-usage.json');

export class JobManager {
  constructor() { this.jobs = new Map(); }

  async init() {
    await fs.mkdir(JOBS_DIR, { recursive: true });
    for (const name of await fs.readdir(JOBS_DIR).catch(() => [])) {
      const file = path.join(JOBS_DIR, name, 'job.json');
      const job = await readJson(file, null);
      if (job) {
        if (job.status === 'running' || job.status === 'starting') job.status = 'paused';
        job.dir = path.join(JOBS_DIR, name);
        job.dataFile = path.join(job.dir, 'data.ndjson');
        job.stopRequested = false;
        this.jobs.set(job.id, job);
      }
    }
  }

  list() { return [...this.jobs.values()].map(publicJob).sort((a, b) => b.createdAt.localeCompare(a.createdAt)); }
  get(id) { return this.jobs.get(id); }

  async create(input) {
    const active = [...this.jobs.values()].find((job) => ['starting','running'].includes(job.status));
    if (active) throw new Error(`Job ${active.id} is already active. Stop it safely or wait for it to finish before starting another job.`);
    const estimate = estimateJob(input);
    if (!estimate.allowed) throw new Error(estimate.errors.join(' '));
    const id = `${new Date().toISOString().slice(0, 10)}-${crypto.randomBytes(8).toString('hex')}`;
    const dir = path.join(JOBS_DIR, id);
    await fs.mkdir(dir, { recursive: true });
    const job = {
      id, status: 'starting', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      config: estimate.config, estimate: compactEstimate(estimate), completedReports: 0,
      collectedRows: 0, current: `Starting ${estimate.config.browser === 'chrome' ? 'Google Chrome' : 'Microsoft Edge'} in ${estimate.config.background ? 'minimized background' : 'visible'} mode…`, error: null, stopRequested: false,
      dir, dataFile: path.join(dir, 'data.ndjson'),
    };
    this.jobs.set(id, job);
    await this.save(job);
    this.run(job).catch(async (error) => {
      job.status = 'paused';
      job.error = error.message;
      job.current = 'Paused safely';
      await this.save(job);
    });
    return publicJob(job);
  }

  async stop(id) {
    const job = this.jobs.get(id);
    if (!job) return null;
    job.stopRequested = true;
    job.current = 'Stop requested; finishing the current page safely…';
    await this.save(job);
    return publicJob(job);
  }

  async resume(id) {
    const job = this.jobs.get(id);
    if (!job) return null;
    if (!['paused','stopped'].includes(job.status)) throw new Error('Only paused or stopped jobs can be resumed.');
    const active = [...this.jobs.values()].find((candidate) => candidate.id !== id && ['starting','running'].includes(candidate.status));
    if (active) throw new Error(`Job ${active.id} is already active. Stop it safely or wait for it to finish before resuming another job.`);
    job.stopRequested = false; job.error = null; job.status = 'starting'; job.current = 'Reopening the browser from the checkpoint…';
    await this.save(job);
    this.run(job).catch(async (error) => { job.status = 'paused'; job.error = error.message; job.current = 'Paused safely'; await this.save(job); });
    return publicJob(job);
  }

  async run(job) {
    const profile = path.join(job.dir, 'browser-profile');
    const channel = job.config.browser === 'chrome' ? 'chrome' : 'msedge';
    let context;
    try {
      context = await chromium.launchPersistentContext(profile, {
        channel, headless: false, args: job.config.background ? ['--start-minimized'] : [], viewport: { width: 1440, height: 980 }, locale: 'en-IN',
      });
    } catch (error) {
      if (/executable|browser.*not found|failed to launch/i.test(error.message)) {
        throw new Error(`${job.config.browser === 'chrome' ? 'Google Chrome' : 'Microsoft Edge'} is not installed or could not be started. Choose the other installed browser and try again.`);
      }
      throw error;
    }
    const page = context.pages()[0] || await context.newPage();
    job.status = 'running';
    await this.save(job);
    try {
      await page.goto(SOURCE_URL, { waitUntil: 'domcontentloaded', timeout: 60_000 });
      await assertSafePage(page);
      await waitForDashboardReady(page);
      const selectors = await resolveDashboardSelectors(page);
      await selectDashboardOption(page, selectors.unit, 'A');
      await selectDashboardOption(page, selectors.yearType, 'C');
      await selectDashboardOption(page, selectors.xAxis, { label: 'Month Wise' });
      const selectedStates = await dashboardOptions(page, selectors.state);
      const allowedStates = job.config.states.includes('ALL') ? selectedStates : selectedStates.filter((s) => job.config.states.includes(s.value));
      if (!allowedStates.length) throw new Error('None of the requested states are currently available on the Vaahan dashboard.');
      let ordinal = 0;
      for (const state of allowedStates) {
        await selectDashboardOption(page, selectors.state, state.value);
        await waitForRtos(page, selectors.rto, state.value);
        await assertSafePage(page);
        const rtos = await dashboardOptions(page, selectors.rto);
        if (!rtos.length) throw new Error(`No public RTOs were returned for ${state.text}.`);
        for (const rto of rtos) {
          for (const segmentId of job.config.segments) {
            const segment = VEHICLE_SEGMENTS.find((s) => s.id === segmentId);
            for (const year of [...new Set(estimateJob(job.config).periods.map((p) => p.year))]) {
              ordinal += 1;
              if (ordinal <= job.completedReports) continue;
              if (job.stopRequested) {
                job.status = 'stopped'; job.current = 'Stopped by user'; await this.save(job); return;
              }
              await enforceDailyLimit(job.config.maxDailyReports);
              job.current = `${state.text} · ${rto.text} · ${segment.label} · ${year}`;
              await this.save(job);
              await selectDashboardOption(page, selectors.rto, rto.value);
              await selectDashboardOption(page, selectors.year, String(year));
              await selectDashboardOption(page, selectors.segment, segment.group);
              const breakdown = BREAKDOWNS.find((b) => b.id === job.config.breakdown);
              await selectDashboardOption(page, selectors.yAxis, { label: breakdown.yAxis });
              await randomPause(job.config.minDelaySeconds, job.config.minDelaySeconds + 30);
              if (job.stopRequested) {
                job.status = 'stopped'; job.current = 'Stopped by user before the next report request'; await this.save(job); return;
              }
              await page.getByRole('button', { name: 'Refresh', exact: true }).click();
              await page.waitForTimeout(6000);
              await assertSafePage(page);
              const raw = await extractReport(page, breakdown.yAxis);
              const records = shapeRecords(raw, { job, state, rto, segment, year, breakdown });
              if (job.collectedRows + records.length > 100_000) throw new Error('Actual output would exceed 100,000 rows. The job was stopped before writing them.');
              await appendNdjson(job.dataFile, records);
              await incrementUsage();
              job.completedReports = ordinal;
              job.collectedRows += records.length;
              await this.save(job);
            }
          }
        }
      }
      job.status = 'complete'; job.current = 'Collection complete'; await this.save(job);
    } finally {
      await context.close();
    }
  }

  async save(job) {
    job.updatedAt = new Date().toISOString();
    await fs.writeFile(path.join(job.dir, 'job.json'), JSON.stringify({ ...job, dir: undefined, dataFile: undefined }, null, 2));
  }
}

async function extractReport(page, heading) {
  let result;
  for (let attempt = 0; attempt < 15; attempt += 1) {
    result = await page.locator('table').evaluateAll((tables, expected) => {
      const candidates = tables.filter((table) => table.rows.length > 1 && table.innerText.toLowerCase().includes(expected.toLowerCase()));
      const table = candidates.at(-1);
      if (!table) return { headers: [], rows: [], diagnostics: { tables: tables.length, candidates: 0, previews: tables.filter((item) => item.rows.length > 1).slice(-3).map((item) => item.innerText.slice(0, 80).replace(/\s+/g, ' ')) } };
      const headers = [...table.querySelectorAll('thead tr:last-child th')].map((cell) => cell.textContent.trim());
      const rows = [...table.querySelectorAll('tbody tr')].map((row) => [...row.querySelectorAll('td')].map((cell) => cell.textContent.trim()));
      return { headers, rows, diagnostics: { tables: tables.length, candidates: candidates.length, tableRows: table.rows.length, bodyRows: rows.length, preview: table.innerText.slice(0, 160).replace(/\s+/g, ' ') } };
    }, heading);
    if (result.rows.length) return result;
    await page.waitForTimeout(2000);
    await assertSafePage(page);
  }
  throw new Error(`No report rows were found after waiting for Vaahan (${JSON.stringify(result.diagnostics)}). The job was paused safely.`);
}

function shapeRecords(raw, { job, state, rto, segment, year, breakdown }) {
  const periods = estimateJob(job.config).periods.filter((p) => p.year === year);
  const numeric = (value) => Number(String(value || '0').replaceAll(',', '')) || 0;
  const sampleWidth = raw.rows.find((row) => row.length)?.length || 0;
  const monthOffset = Math.max(0, sampleWidth - raw.headers.length - 1);
  const dimensionIndex = Math.max(0, monthOffset - 1);
  const monthColumns = raw.headers.map((h, i) => ({ h, i: i + monthOffset })).filter(({ h }) => /jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/i.test(h));
  const rows = [];
  for (const period of periods) {
    const indices = job.config.periodMode === 'month'
      ? monthColumns.filter(({ h }) => h.toLowerCase().startsWith(['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'][period.period - 1])).map((c) => c.i)
      : monthColumns.slice((period.period - 1) * 3, period.period * 3).map((c) => c.i);
    for (const rawRow of raw.rows) {
      const dimension = rawRow[dimensionIndex] || 'Total';
      const registrations = indices.length ? indices.reduce((sum, i) => sum + numeric(rawRow[i]), 0) : 0;
      rows.push({ period: period.label, state: state.text, state_code: state.value, rto: rto.text, rto_code: rto.value,
        vehicle_segment: segment.label, breakdown: breakdown.label, dimension, registrations,
        source_url: SOURCE_URL, collected_at_utc: new Date().toISOString() });
    }
  }
  if (breakdown.id !== 'total') return rows;
  const totals = new Map();
  for (const row of rows) totals.set(row.period, (totals.get(row.period) || 0) + row.registrations);
  return [...totals].map(([period, registrations]) => ({ ...rows.find((r) => r.period === period), dimension: 'Total', registrations }));
}

async function dashboardOptions(page, selector) {
  return page.locator(selector).evaluate((select) => [...select.options]
    .filter((o) => o.value && o.value !== '-1').map((o) => ({ value: o.value, text: o.textContent.trim() })));
}
async function resolveDashboardSelectors(page) {
  const selectors = await page.locator('select').evaluateAll((selects) => {
    const options = (select) => [...select.options].map((option) => ({ value: option.value, text: option.textContent.trim() }));
    const hasValue = (select, value) => options(select).some((option) => option.value === value);
    const hasText = (select, value) => options(select).some((option) => option.text.toLowerCase() === value.toLowerCase());
    const selector = (select) => select?.id ? `#${CSS.escape(select.id)}` : null;
    const find = (predicate) => selector(selects.find(predicate));
    return {
      unit: find((select) => hasText(select, 'Actual Value') && hasText(select, 'In Thousand')),
      state: find((select) => hasValue(select, 'AN') && hasValue(select, 'AP') && hasValue(select, 'CH')),
      rto: find((select) => options(select).some((option) => /Vahan4 Running Office/i.test(option.text))),
      yAxis: find((select) => hasValue(select, 'Maker') && hasValue(select, 'Fuel') && hasValue(select, 'Vehicle Class')),
      xAxis: find((select) => hasValue(select, 'Month Wise') && hasValue(select, 'Financial Year')),
      yearType: find((select) => hasValue(select, 'F') && hasValue(select, 'C') && hasText(select, 'Select')),
      year: find((select) => hasText(select, 'Select Year') && options(select).some((option) => /^20\d{2}$/.test(option.value))),
      segment: find((select) => options(select).some((option) => option.value.startsWith('2W|')) && options(select).some((option) => option.value.startsWith('TR|'))),
    };
  });
  const missing = Object.entries(selectors).filter(([, selector]) => !selector).map(([name]) => name);
  if (missing.length) throw new Error(`Vaahan dashboard controls changed (${missing.join(', ')} not found). The job was paused before making report requests.`);
  return selectors;
}
async function waitForDashboardReady(page) {
  await page.waitForFunction(() => [...document.querySelectorAll('select option')]
    .some((option) => String(option.value).startsWith('TR|')), null, { timeout: 45_000 }).catch(() => {
    throw new Error('Vaahan did not finish loading its dashboard controls. The job was paused before making report requests.');
  });
}
async function selectDashboardOption(page, selector, choice) {
  const locator = page.locator(selector);
  const matches = async () => locator.evaluate((select, expected) => {
    const selected = select.selectedOptions[0];
    return typeof expected === 'string' ? select.value === expected : selected?.textContent.trim() === expected.label;
  }, choice);
  await locator.selectOption(choice, { force: true });
  await page.waitForTimeout(1600);
  if (await matches()) return;
  await locator.selectOption(choice, { force: true });
  await page.waitForTimeout(2200);
  if (!await matches()) throw new Error(`Vaahan reset a dashboard filter (${selector}). The job was paused before refreshing the report.`);
}
async function waitForRtos(page, selector, stateCode) {
  await page.waitForTimeout(1200);
  await page.waitForFunction(({ selector: css }) => {
    const select = document.querySelector(css);
    return select && [...select.options].some((option) => option.value && option.value !== '-1');
  }, { selector }, { timeout: 30_000 }).catch(() => {
    throw new Error(`Vaahan did not return RTO options for state ${stateCode}. The job was paused safely.`);
  });
}
async function assertSafePage(page) {
  const snapshot = await page.evaluate(() => ({ title: document.title, text: document.body.innerText.slice(0, 12000).toLowerCase() }));
  if (/captcha|verify you are human|access denied/.test(snapshot.text)) throw new Error('CAPTCHA or access challenge detected. No bypass was attempted.');
  if (/too many requests|rate limit|temporarily blocked/.test(snapshot.text)) throw new Error('Vaahan reported a rate limit. The job was paused.');
  if (!/vahan/.test((snapshot.title || '').toLowerCase())) throw new Error('Unexpected page. The job was paused for review.');
}
async function randomPause(min, max) { await new Promise((resolve) => setTimeout(resolve, (min + Math.random() * (max - min)) * 1000)); }
async function appendNdjson(file, records) { if (records.length) await fs.appendFile(file, records.map((r) => JSON.stringify(r)).join('\n') + '\n'); }
async function readJson(file, fallback) { try { return JSON.parse(await fs.readFile(file, 'utf8')); } catch { return fallback; } }
function indiaDate() { return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(new Date()); }
async function enforceDailyLimit(max) { const u = await readJson(USAGE_FILE, { date: indiaDate(), count: 0 }); const count = u.date === indiaDate() ? u.count : 0; if (count >= max) throw new Error(`Daily safety limit (${max}) reached. Resume tomorrow.`); }
async function incrementUsage() { const today = indiaDate(); const u = await readJson(USAGE_FILE, { date: today, count: 0 }); const next = { date: today, count: u.date === today ? u.count + 1 : 1 }; await fs.mkdir(path.dirname(USAGE_FILE), { recursive: true }); await fs.writeFile(USAGE_FILE, JSON.stringify(next, null, 2)); }
function compactEstimate(e) { return { estimatedRows: e.estimatedRows, reportRequests: e.reportRequests, estimatedDays: e.estimatedDays, estimatedActiveHours: e.estimatedActiveHours, rtoCount: e.rtoCount }; }
function publicJob(job) { return { id: job.id, status: job.status, createdAt: job.createdAt, updatedAt: job.updatedAt, config: job.config, estimate: job.estimate, completedReports: job.completedReports, collectedRows: job.collectedRows, current: job.current, error: job.error }; }
