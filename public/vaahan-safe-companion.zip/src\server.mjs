import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { BREAKDOWNS, STATE_COUNTS, VEHICLE_SEGMENTS } from './catalog.mjs';
import { estimateJob, MAX_DAILY_REPORTS, MAX_OUTPUT_ROWS, MIN_DELAY_SECONDS } from './estimator.mjs';
import { JobManager, publicJob } from './job-manager.mjs';
import { exportCsv, exportXlsx } from './export-xlsx.mjs';

const ROOT = process.cwd();
const PUBLIC = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || 4173);
const SESSION_TOKEN = crypto.randomBytes(32).toString('base64url');
const PAIRING_CODE = crypto.randomBytes(4).toString('hex').toUpperCase();
const mutationTimes = [];
const pairingAttemptTimes = [];
const exportTimes = [];
const activeExports = new Set();
const ALLOWED_ORIGINS = new Set([
  'https://yashbhakat.github.io',
  `http://127.0.0.1:${PORT}`,
  `http://localhost:${PORT}`,
]);
const manager = new JobManager();
await manager.init();

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    applySecurityHeaders(res, url.pathname);
    applyCors(req, res);
    if (req.method === 'OPTIONS') {
      if (!isAllowedOrigin(req.headers.origin)) return json(res, 403, { error: 'Origin not allowed' });
      res.writeHead(204);
      return res.end();
    }
    if (req.method === 'GET' && url.pathname === '/api/health') return json(res, 200, { status: 'ready', browsers: ['edge','chrome'], background: true, version: 5, capabilities: ['local-auto-open','pairing-code','one-click-pairing','automatic-export','auto-recovery','adaptive-pacing','deduplicated-checkpoints','live-eta'] });
    if (req.method === 'GET' && url.pathname === '/api/pair-code') {
      if (!isLoopbackClient(req)) return json(res, 403, { error: 'Pairing code is available only in the local control room.' });
      return json(res, 200, { code: formatPairingCode(PAIRING_CODE), expires: 'server-restart' });
    }
    if (req.method === 'GET' && url.pathname === '/api/session') {
      if (!isTrustedClient(req)) return json(res, 403, { error: 'Client not allowed' });
      if (!isLoopbackClient(req)) {
        if (!takePairingAttemptSlot()) return json(res, 429, { error: 'Too many pairing attempts. Wait one minute and try again.' });
        if (!hasValidPairingCode(req)) return json(res, 403, { error: 'Enter the pairing code shown in the local control room.' });
      }
      return json(res, 200, { token: SESSION_TOKEN, expires: 'server-restart' });
    }
    if (url.pathname.startsWith('/api/')) {
      if (!isTrustedClient(req)) return json(res, 403, { error: 'Client not allowed' });
      if (!hasValidToken(req)) return json(res, 401, { error: 'Collector session expired. Reconnect to the local bridge.' });
      if (req.method === 'POST') {
        if (!String(req.headers['content-type'] || '').toLowerCase().startsWith('application/json')) return json(res, 415, { error: 'JSON content type required' });
        if (!takeMutationSlot()) return json(res, 429, { error: 'Too many local control requests. Wait one minute and try again.' });
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/options') return json(res, 200, { segments: VEHICLE_SEGMENTS, breakdowns: BREAKDOWNS, states: STATE_COUNTS, limits: { maxRows: MAX_OUTPUT_ROWS, maxDailyReports: MAX_DAILY_REPORTS, minDelaySeconds: MIN_DELAY_SECONDS } });
    if (req.method === 'GET' && url.pathname === '/api/jobs') return json(res, 200, manager.list());
    if (req.method === 'POST' && url.pathname === '/api/estimate') return json(res, 200, estimateJob(await body(req)));
    if (req.method === 'POST' && url.pathname === '/api/jobs') return json(res, 201, await manager.create(await body(req)));
    const match = url.pathname.match(/^\/api\/jobs\/([a-z0-9-]+)(?:\/(stop|resume|export))?$/i);
    if (match) {
      const job = manager.get(match[1]);
      if (!job) return json(res, 404, { error: 'Job not found' });
      if (req.method === 'GET' && !match[2]) return json(res, 200, publicJob(job));
      if (req.method === 'POST' && match[2] === 'stop') return json(res, 200, await manager.stop(job.id));
      if (req.method === 'POST' && match[2] === 'resume') return json(res, 200, await manager.resume(job.id));
      if (req.method === 'GET' && match[2] === 'export') {
        if (!takeExportSlot()) return json(res, 429, { error: 'Too many export requests. Wait one minute and try again.' });
        return sendExport(res, job, url.searchParams.get('format') || 'xlsx');
      }
    }
    if (req.method !== 'GET') return json(res, 404, { error: 'Not found' });
    const relative = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
    const file = path.resolve(PUBLIC, relative);
    const relativeToPublic = path.relative(path.resolve(PUBLIC), file);
    if (relativeToPublic.startsWith('..') || path.isAbsolute(relativeToPublic)) return json(res, 403, { error: 'Forbidden' });
    const data = await fs.readFile(file);
    res.writeHead(200, { 'Content-Type': mime(path.extname(file)), 'Cache-Control': 'no-cache' }); res.end(data);
  } catch (error) {
    const safe = clientError(error);
    if (safe.status >= 500) console.error(error);
    json(res, safe.status, { error: safe.message });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`Vaahan Safe Data Collector: http://127.0.0.1:${PORT}`);
  console.log(`Pairing code: ${formatPairingCode(PAIRING_CODE)}`);
  openLocalControlRoom();
});

function openLocalControlRoom() {
  if (process.platform !== 'win32' || process.env.VAAHAN_NO_AUTO_OPEN === '1') return;
  const controlRoom = `http://127.0.0.1:${PORT}`;
  const child = spawn('powershell.exe', ['-NoProfile','-NonInteractive','-WindowStyle','Hidden','-Command', `Start-Process -FilePath 'msedge.exe' -ArgumentList '${controlRoom}'`], { windowsHide:true, detached:true, stdio:'ignore' });
  child.on('error', () => console.log(`Open ${controlRoom} in Edge to use the local control room.`));
  child.unref();
}

function applyCors(req, res) {
  const origin = req.headers.origin;
  if (!isAllowedOrigin(origin)) return;
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Collector-Token, X-Collector-Pairing-Code');
  res.setHeader('Access-Control-Allow-Private-Network', 'true');
  res.setHeader('Access-Control-Max-Age', '600');
  res.setHeader('Vary', 'Origin, Access-Control-Request-Private-Network');
}

function applySecurityHeaders(res, pathname) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  if (pathname.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  else res.setHeader('Content-Security-Policy', "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
}

function isAllowedOrigin(origin) { return typeof origin === 'string' && ALLOWED_ORIGINS.has(origin); }
function isLoopbackClient(req) {
  const origin = String(req.headers.origin || '').toLowerCase();
  if (origin) return origin === `http://127.0.0.1:${PORT}` || origin === `http://localhost:${PORT}`;
  if (String(req.headers['sec-fetch-site'] || '').toLowerCase() === 'cross-site') return false;
  const host = String(req.headers.host || '').toLowerCase().split(':')[0];
  return ['127.0.0.1','localhost','[::1]'].includes(host);
}
function isTrustedClient(req) {
  if (req.headers.origin) return isAllowedOrigin(req.headers.origin);
  if (String(req.headers['sec-fetch-site'] || '').toLowerCase() === 'cross-site') return false;
  const host = String(req.headers.host || '').toLowerCase().split(':')[0];
  return ['127.0.0.1','localhost','[::1]'].includes(host);
}
function hasValidPairingCode(req) {
  const provided = normalizePairingCode(req.headers['x-collector-pairing-code']);
  if (provided.length !== PAIRING_CODE.length) return false;
  return crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(PAIRING_CODE));
}
function hasValidToken(req) {
  const provided = req.headers['x-collector-token'];
  if (typeof provided !== 'string' || provided.length !== SESSION_TOKEN.length) return false;
  return crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(SESSION_TOKEN));
}
function takeMutationSlot() {
  const cutoff = Date.now() - 60_000;
  while (mutationTimes.length && mutationTimes[0] < cutoff) mutationTimes.shift();
  if (mutationTimes.length >= 30) return false;
  mutationTimes.push(Date.now());
  return true;
}
function takePairingAttemptSlot() {
  const cutoff = Date.now() - 60_000;
  while (pairingAttemptTimes.length && pairingAttemptTimes[0] < cutoff) pairingAttemptTimes.shift();
  if (pairingAttemptTimes.length >= 5) return false;
  pairingAttemptTimes.push(Date.now());
  return true;
}
function takeExportSlot() {
  const cutoff = Date.now() - 60_000;
  while (exportTimes.length && exportTimes[0] < cutoff) exportTimes.shift();
  if (exportTimes.length >= 10) return false;
  exportTimes.push(Date.now());
  return true;
}

async function sendExport(res, job, format) {
  if (!['xlsx','csv','pdf'].includes(format)) return json(res, 400, { error: 'Unsupported format' });
  if (format === 'pdf' && job.collectedRows > 2000) return json(res, 400, { error: 'PDF is capped at 2,000 detail rows.' });
  const exportKey = `${job.id}:${format}`;
  if (activeExports.has(exportKey)) return json(res, 409, { error: 'That export is already being prepared.' });
  activeExports.add(exportKey);
  try {
    const output = path.join(job.dir, `vaahan-${job.id}.${format}`);
    if (format === 'xlsx') await exportXlsx(job, output);
    if (format === 'csv') await exportCsv(job, output);
    if (format === 'pdf') await runPdf(path.join(job.dir, 'job.json'), job.dataFile, output);
    const data = await fs.readFile(output);
    res.writeHead(200, { 'Content-Type': mime(`.${format}`), 'Content-Disposition': `attachment; filename="${path.basename(output)}"`, 'Content-Length': data.length }); res.end(data);
  } finally {
    activeExports.delete(exportKey);
  }
}
function runPdf(jobFile, dataFile, output) { return new Promise((resolve, reject) => { const child = spawn(process.env.PYTHON || 'python', [path.join(ROOT, 'scripts', 'export_pdf.py'), jobFile, dataFile, output], { windowsHide: true }); let err=''; child.stderr.on('data',(d)=>err+=d); child.on('error',reject); child.on('close',(code)=>code===0?resolve():reject(new Error(err || `PDF export failed (${code})`))); }); }
function body(req) { return new Promise((resolve, reject) => { let raw=''; let bytes=0; let tooLarge=false; req.on('data',(chunk)=>{ if (tooLarge) return; bytes+=chunk.length; if(bytes>1_000_000){ tooLarge=true; raw=''; reject(new Error('Request too large')); return; } raw+=chunk; }); req.on('end',()=>{ if (tooLarge) return; try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('Invalid JSON')); } }); req.on('error',reject); }); }
function json(res, status, value) { const data=Buffer.from(JSON.stringify(value)); res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':data.length}); res.end(data); }
function normalizePairingCode(value) { return String(value || '').toUpperCase().replace(/[^A-F0-9]/g, '').slice(0, 8); }
function formatPairingCode(value) { const normalized=normalizePairingCode(value); return `${normalized.slice(0,4)}-${normalized.slice(4)}`; }
function clientError(error) {
  if (error?.code === 'ENOENT') return { status:404, message:'Not found' };
  const message=String(error?.message || 'Unexpected collector error');
  if (error?.code === 'EACCES' || error?.code === 'EPERM' || /(?:[A-Z]:\\|node_modules|file:\/\/)/i.test(message)) return { status:500, message:'Internal collector error. Review the local companion window for details.' };
  return { status:400, message:message.slice(0,500) };
}
function mime(ext) { return ({'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.csv':'text/csv; charset=utf-8','.pdf':'application/pdf'}[ext] || 'application/octet-stream'); }
