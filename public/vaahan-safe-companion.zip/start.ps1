$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
$bundledNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
$nodePath = if ($nodeCommand) { $nodeCommand.Source } elseif (Test-Path -LiteralPath $bundledNode) { $bundledNode } else { $null }
if (-not $nodePath) { throw 'Node.js was not found. Install Node.js 20+ or run this project from Codex Desktop.' }
$bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (Test-Path -LiteralPath $bundledPython) { $env:PYTHON = $bundledPython }
Write-Host 'Serving the secure Vaahan companion at http://127.0.0.1:4173 (press Ctrl+C to stop)'
& $nodePath (Join-Path $PSScriptRoot 'src\server.mjs')
