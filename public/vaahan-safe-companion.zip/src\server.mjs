import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { BREAKDOWNS, STATE_COUNTS, VEHICLE_SEGMENTS } from './catalog.mjs';
import { estimateJob, MAX_DAILY_REPORTS, MAX_OUTPUT_ROWS, MIN_DELAY_SECONDS } from './estimator.mjs';
import { JobManager } from './job-manager.mjs';
import { exportCsv, exportXlsx } from './export-xlsx.mjs';

const ROOT = process.cwd();
const PUBLIC = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || 4173);
const SESSION_TOKEN = crypto.randomBytes(32).toString('base64url');
const mutationTimes = [];
const ALLOWED_ORIGINS = new Set([
  'https://yashbhakat.github.io',
  `http://127.0.0.1:${PORT}`,
  `http://localhost:${PORT}`,
]);
const manager = new JobManager();
await manager.init();

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    applySecurityHeaders(res, url.pathname);
    applyCors(req, res);
    if (req.method === 'OPTIONS') {
      if (!isAllowedOrigin(req.headers.origin)) return json(res, 403, { error: 'Origin not allowed' });
      res.writeHead(204);
      return res.end();
    }
    if (req.method === 'GET' && url.pathname === '/api/health') return json(res, 200, { status: 'ready', browsers: ['edge','chrome'], background: true, version: 2 });
    if (req.method === 'GET' && url.pathname === '/api/session') {
      if (!isTrustedClient(req)) return json(res, 403, { error: 'Client not allowed' });
      return json(res, 200, { token: SESSION_TOKEN, expires: 'server-restart' });
    }
    if (url.pathname.startsWith('/api/')) {
      if (!isTrustedClient(req)) return json(res, 403, { error: 'Client not allowed' });
      if (!hasValidToken(req)) return json(res, 401, { error: 'Collector session expired. Reconnect to the local bridge.' });
      if (req.method === 'POST') {
        if (!String(req.headers['content-type'] || '').toLowerCase().startsWith('application/json')) return json(res, 415, { error: 'JSON content type required' });
        if (!takeMutationSlot()) return json(res, 429, { error: 'Too many local control requests. Wait one minute and try again.' });
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/options') return json(res, 200, { segments: VEHICLE_SEGMENTS, breakdowns: BREAKDOWNS, states: STATE_COUNTS, limits: { maxRows: MAX_OUTPUT_ROWS, maxDailyReports: MAX_DAILY_REPORTS, minDelaySeconds: MIN_DELAY_SECONDS } });
    if (req.method === 'GET' && url.pathname === '/api/jobs') return json(res, 200, manager.list());
    if (req.method === 'POST' && url.pathname === '/api/estimate') return json(res, 200, estimateJob(await body(req)));
    if (req.method === 'POST' && url.pathname === '/api/jobs') return json(res, 201, await manager.create(await body(req)));
    const match = url.pathname.match(/^\/api\/jobs\/([a-z0-9-]+)(?:\/(stop|resume|export))?$/i);
    if (match) {
      const job = manager.get(match[1]);
      if (!job) return json(res, 404, { error: 'Job not found' });
      if (req.method === 'GET' && !match[2]) return json(res, 200, publicJob(job));
      if (req.method === 'POST' && match[2] === 'stop') return json(res, 200, await manager.stop(job.id));
      if (req.method === 'POST' && match[2] === 'resume') return json(res, 200, await manager.resume(job.id));
      if (req.method === 'GET' && match[2] === 'export') return sendExport(res, job, url.searchParams.get('format') || 'xlsx');
    }
    if (req.method !== 'GET') return json(res, 404, { error: 'Not found' });
    const relative = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
    const file = path.resolve(PUBLIC, relative);
    const relativeToPublic = path.relative(path.resolve(PUBLIC), file);
    if (relativeToPublic.startsWith('..') || path.isAbsolute(relativeToPublic)) return json(res, 403, { error: 'Forbidden' });
    const data = await fs.readFile(file);
    res.writeHead(200, { 'Content-Type': mime(path.extname(file)), 'Cache-Control': 'no-cache' }); res.end(data);
  } catch (error) { json(res, 400, { error: error.message }); }
});

server.listen(PORT, '127.0.0.1', () => console.log(`Vaahan Safe Data Collector: http://127.0.0.1:${PORT}`));

function applyCors(req, res) {
  const origin = req.headers.origin;
  if (!isAllowedOrigin(origin)) return;
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Collector-Token');
  res.setHeader('Access-Control-Allow-Private-Network', 'true');
  res.setHeader('Access-Control-Max-Age', '600');
  res.setHeader('Vary', 'Origin, Access-Control-Request-Private-Network');
}

function applySecurityHeaders(res, pathname) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  if (pathname.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  else res.setHeader('Content-Security-Policy', "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
}

function isAllowedOrigin(origin) { return typeof origin === 'string' && ALLOWED_ORIGINS.has(origin); }
function isTrustedClient(req) {
  if (req.headers.origin) return isAllowedOrigin(req.headers.origin);
  if (String(req.headers['sec-fetch-site'] || '').toLowerCase() === 'cross-site') return false;
  const host = String(req.headers.host || '').toLowerCase().split(':')[0];
  return ['127.0.0.1','localhost','[::1]'].includes(host);
}
function hasValidToken(req) {
  const provided = req.headers['x-collector-token'];
  if (typeof provided !== 'string' || provided.length !== SESSION_TOKEN.length) return false;
  return crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(SESSION_TOKEN));
}
function takeMutationSlot() {
  const cutoff = Date.now() - 60_000;
  while (mutationTimes.length && mutationTimes[0] < cutoff) mutationTimes.shift();
  if (mutationTimes.length >= 30) return false;
  mutationTimes.push(Date.now());
  return true;
}

async function sendExport(res, job, format) {
  if (!['xlsx','csv','pdf'].includes(format)) return json(res, 400, { error: 'Unsupported format' });
  if (format === 'pdf' && job.collectedRows > 2000) return json(res, 400, { error: 'PDF is capped at 2,000 detail rows.' });
  const output = path.join(job.dir, `vaahan-${job.id}.${format}`);
  if (format === 'xlsx') await exportXlsx(job, output);
  if (format === 'csv') await exportCsv(job, output);
  if (format === 'pdf') await runPdf(path.join(job.dir, 'job.json'), job.dataFile, output);
  const data = await fs.readFile(output);
  res.writeHead(200, { 'Content-Type': mime(`.${format}`), 'Content-Disposition': `attachment; filename="${path.basename(output)}"`, 'Content-Length': data.length }); res.end(data);
}
function runPdf(jobFile, dataFile, output) { return new Promise((resolve, reject) => { const child = spawn(process.env.PYTHON || 'python', [path.join(ROOT, 'scripts', 'export_pdf.py'), jobFile, dataFile, output], { windowsHide: true }); let err=''; child.stderr.on('data',(d)=>err+=d); child.on('error',reject); child.on('close',(code)=>code===0?resolve():reject(new Error(err || `PDF export failed (${code})`))); }); }
function body(req) { return new Promise((resolve, reject) => { let raw=''; req.on('data',(c)=>{ raw+=c; if(raw.length>1_000_000) reject(new Error('Request too large')); }); req.on('end',()=>{ try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('Invalid JSON')); } }); }); }
function json(res, status, value) { const data=Buffer.from(JSON.stringify(value)); res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':data.length}); res.end(data); }
function publicJob(j) { return { id:j.id,status:j.status,createdAt:j.createdAt,updatedAt:j.updatedAt,config:j.config,estimate:j.estimate,completedReports:j.completedReports,collectedRows:j.collectedRows,current:j.current,error:j.error }; }
function mime(ext) { return ({'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.csv':'text/csv; charset=utf-8','.pdf':'application/pdf'}[ext] || 'application/octet-stream'); }
