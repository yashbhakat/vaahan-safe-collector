import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = process.cwd();
const outputDir = path.join(root, "outputs", "vaahan-tractor-sheet");
await fs.mkdir(outputDir, { recursive: true });
const sample = JSON.parse(await fs.readFile(path.join(root, "data", "sample_2026_all_india.json"), "utf8"));

const wb = Workbook.create();
const readme = wb.worksheets.add("README");
const data = wb.worksheets.add("Tractor Data");
const log = wb.worksheets.add("Run Log");
const config = wb.worksheets.add("Config");

readme.getRange("A1:F1").merge();
readme.getRange("A1").values = [["Vaahan Tractor Registration Dataset"]];
readme.getRange("A3:B11").values = [
  ["Field", "Meaning"],
  ["Source", "https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml"],
  ["Coverage requested", "All Vaahan states, all RTOs, calendar years 2022–2026"],
  ["Current contents", "Verified 2026 all-India maker-level sample plus collection schema"],
  ["Product grain", "Maker. The public report does not expose tractor model."],
  ["Metric", "Vehicle registrations; use as a sales proxy, not invoiced retail sales."],
  ["Tractor scope", "Agricultural Tractor; Tractor (Commercial); Tractor-Trolley (Commercial)"],
  ["Collection policy", "Visible browser, one request at a time, 45–75s jitter, max 80 reports/day, resumable"],
  ["Safety", "Stops on CAPTCHA, access challenge, 403/429 indicators, or unexpected page layout"]
];
readme.showGridLines = false;
readme.getRange("A1:F1").format = { fill: "#E8EAED", font: { bold: true, size: 16 }, rowHeight: 30 };
readme.getRange("A3:B3").format = { fill: "#E8EAED", font: { bold: true } };
readme.getRange("A3:B11").format.borders = { preset: "insideHorizontal", style: "thin", color: "#DADCE0" };
readme.getRange("A:B").format.columnWidth = 28;
readme.getRange("B:B").format.columnWidth = 72;
readme.getRange("B3:B11").format.wrapText = true;

const headers = [
  "calendar_year","state","state_code","rto","rto_code","maker","model",
  "product_granularity","vehicle_group","lmv","mmv","lgv","mgv","hgv","oth",
  "total","source_url","collected_at_utc"
];
data.getRangeByIndexes(0, 0, 1, headers.length).values = [headers];
const now = new Date();
const rows = sample.map(r => [
  2026, "All Vahan4 Running States", "-1", "All Vahan4 Running Office", "-1",
  r[0], "", "maker", "TRACTOR", ...r.slice(1),
  "https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml", now
]);
data.getRangeByIndexes(1, 0, rows.length, headers.length).values = rows;
data.getRangeByIndexes(1, 9, rows.length, 7).format.numberFormat = "#,##0";
data.getRangeByIndexes(1, 17, rows.length, 1).format.numberFormat = "yyyy-mm-dd hh:mm";
data.freezePanes.freezeRows(1);
data.freezePanes.freezeColumns(2);
const dataTable = data.tables.add(`A1:R${rows.length + 1}`, true, "TractorDataTable");
dataTable.style = "TableStyleLight1";
data.getRangeByIndexes(0, 0, 1, headers.length).format = {
  fill: "#E8EAED",
  font: { bold: true, color: "#202124" }
};
data.getRange("A:R").format.columnWidth = 14;
data.getRange("B:B").format.columnWidth = 24;
data.getRange("D:D").format.columnWidth = 28;
data.getRange("F:F").format.columnWidth = 46;
data.getRange("H:H").format.columnWidth = 22;
data.getRange("I:I").format.columnWidth = 18;
data.getRange("Q:Q").format.columnWidth = 65;
data.getRange("R:R").format.columnWidth = 22;

log.getRange("A1:H2").values = [
  ["run_date_ist","state","rto","year","status","rows_added","message","checkpoint"],
  [new Date(),"All India","All RTOs",2026,"Sample verified",rows.length,"Public report exposes maker, not model","starter"]
];
log.getRange("A1:H1").format = { fill: "#E8EAED", font: { bold: true } };
log.getRange("A2:A2").format.numberFormat = "yyyy-mm-dd hh:mm";
log.getRange("E2:E1000").dataValidation = { rule: { type: "list", values: ["Pending","Running","Complete","Stopped safely","Sample verified"] } };
log.freezePanes.freezeRows(1);
log.getRange("A:H").format.columnWidth = 20;
log.getRange("G:G").format.columnWidth = 48;

config.getRange("A1:B12").values = [
  ["Setting","Value"],
  ["source_url","https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml"],
  ["start_year",2022],
  ["end_year",2026],
  ["min_delay_seconds",45],
  ["max_delay_seconds",75],
  ["daily_report_limit",80],
  ["concurrency",1],
  ["vehicle_group","TRACTOR"],
  ["vehicle_classes","13 Agricultural Tractor; 63 Tractor (Commercial); 90 Tractor-Trolley (Commercial)"],
  ["product_granularity","maker"],
  ["model_availability","Not exposed by this public report"]
];
config.getRange("A1:B1").format = { fill: "#E8EAED", font: { bold: true } };
config.getRange("A:B").format.columnWidth = 30;
config.getRange("B:B").format.columnWidth = 70;
config.getRange("B2:B12").format.wrapText = true;

for (const name of ["README","Tractor Data","Run Log","Config"]) {
  const s = wb.worksheets.getItem(name);
  const used = s.getUsedRange();
  used.format.font = { name: "Arial", size: 10 };
}

const checks = await wb.inspect({
  kind: "table",
  range: "Tractor Data!A1:R12",
  include: "values,formulas",
  tableMaxRows: 12,
  tableMaxCols: 18
});
console.log(checks.ndjson);
const errors = await wb.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "formula error scan"
});
console.log(errors.ndjson);

for (const name of ["README","Tractor Data","Run Log","Config"]) {
  const preview = await wb.render({ sheetName: name, autoCrop: "all", scale: 1, format: "png" });
  await fs.writeFile(path.join(outputDir, `${name.replaceAll(" ", "_")}.png`), new Uint8Array(await preview.arrayBuffer()));
}

const out = await SpreadsheetFile.exportXlsx(wb);
await out.save(path.join(outputDir, "Vaahan_Tractor_Registration_Tracker.xlsx"));
console.log(path.join(outputDir, "Vaahan_Tractor_Registration_Tracker.xlsx"));
