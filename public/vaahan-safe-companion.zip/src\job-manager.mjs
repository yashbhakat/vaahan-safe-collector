import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { chromium } from 'playwright';
import { BREAKDOWNS, SOURCE_URL, VEHICLE_SEGMENTS } from './catalog.mjs';
import { estimateJob } from './estimator.mjs';

const ROOT = process.cwd();
const JOBS_DIR = path.join(ROOT, 'data', 'jobs');
const USAGE_FILE = path.join(ROOT, 'data', 'daily-usage.json');
const ACTIVE_STATUSES = ['starting','running','waiting','recovering'];
const RECOVERY_DELAYS_MS = [45_000, 90_000];

export class JobManager {
  constructor() { this.jobs = new Map(); }

  async init() {
    await fs.mkdir(JOBS_DIR, { recursive: true });
    for (const name of await fs.readdir(JOBS_DIR).catch(() => [])) {
      const file = path.join(JOBS_DIR, name, 'job.json');
      const job = await readJson(file, null);
      if (job) {
        if (ACTIVE_STATUSES.includes(job.status)) job.status = 'paused';
        job.dir = path.join(JOBS_DIR, name);
        job.dataFile = path.join(job.dir, 'data.ndjson');
        job.stopRequested = false;
        this.jobs.set(job.id, job);
      }
    }
  }

  list() { return [...this.jobs.values()].map(publicJob).sort((a, b) => b.createdAt.localeCompare(a.createdAt)); }
  get(id) { return this.jobs.get(id); }

  async create(input) {
    const active = [...this.jobs.values()].find((job) => ACTIVE_STATUSES.includes(job.status));
    if (active) throw new Error(`Job ${active.id} is already active. Stop it safely or wait for it to finish before starting another job.`);
    const estimate = estimateJob(input);
    if (!estimate.allowed) throw new Error(estimate.errors.join(' '));
    const id = `${new Date().toISOString().slice(0, 10)}-${crypto.randomBytes(8).toString('hex')}`;
    const dir = path.join(JOBS_DIR, id);
    await fs.mkdir(dir, { recursive: true });
    const job = {
      id, status: 'starting', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      config: estimate.config, estimate: compactEstimate(estimate), completedReports: 0,
      collectedRows: 0, current: `Starting ${estimate.config.browser === 'chrome' ? 'Google Chrome' : 'Microsoft Edge'} in ${estimate.config.background ? 'minimized background' : 'visible'} mode…`, error: null, stopRequested: false,
      autoRecoveries: 0, averageReportSeconds: null, adaptiveDelaySeconds: 0,
      dir, dataFile: path.join(dir, 'data.ndjson'),
    };
    this.jobs.set(id, job);
    await this.save(job);
    this.runWithRecovery(job).catch((error) => this.failSafely(job, error));
    return publicJob(job);
  }

  async stop(id) {
    const job = this.jobs.get(id);
    if (!job) return null;
    job.stopRequested = true;
    job.current = 'Stop requested; finishing the current page safely…';
    await this.save(job);
    return publicJob(job);
  }

  async resume(id) {
    const job = this.jobs.get(id);
    if (!job) return null;
    if (!['paused','stopped'].includes(job.status)) throw new Error('Only paused or stopped jobs can be resumed.');
    const active = [...this.jobs.values()].find((candidate) => candidate.id !== id && ACTIVE_STATUSES.includes(candidate.status));
    if (active) throw new Error(`Job ${active.id} is already active. Stop it safely or wait for it to finish before resuming another job.`);
    job.stopRequested = false; job.error = null; job.status = 'starting'; job.current = 'Reopening the browser from the checkpoint…';
    await this.save(job);
    this.runWithRecovery(job).catch((error) => this.failSafely(job, error));
    return publicJob(job);
  }

  async failSafely(job, error) {
    job.status = 'paused';
    job.error = error.message;
    job.current = 'Paused safely after an internal recovery error.';
    await this.save(job).catch(() => {});
  }

  async runWithRecovery(job) {
    for (let attempt = 0; attempt <= RECOVERY_DELAYS_MS.length; attempt += 1) {
      try {
        await this.run(job);
        return;
      } catch (error) {
        if (job.stopRequested) {
          job.status = 'stopped';
          job.current = 'Stopped by user';
          job.error = null;
          await this.save(job);
          return;
        }
        if (!isRecoverableError(error) || attempt === RECOVERY_DELAYS_MS.length) {
          job.status = 'paused';
          job.error = error.message;
          job.current = 'Paused safely; review the message before resuming.';
          await this.save(job);
          return;
        }
        const delayMs = RECOVERY_DELAYS_MS[attempt];
        job.status = 'recovering';
        job.autoRecoveries = (job.autoRecoveries || 0) + 1;
        job.error = null;
        job.current = `Temporary browser or dashboard issue detected. Automatic recovery ${attempt + 1}/${RECOVERY_DELAYS_MS.length} will reopen from the last checkpoint in ${Math.round(delayMs / 1000)} seconds.`;
        await this.save(job);
        if (!await this.waitForRecoveryDelay(job, delayMs)) return;
        job.status = 'starting';
        job.current = 'Reopening the browser automatically from the last completed checkpoint…';
        await this.save(job);
      }
    }
  }

  async waitForRecoveryDelay(job, delayMs) {
    const deadline = Date.now() + delayMs;
    while (Date.now() < deadline) {
      if (job.stopRequested) {
        job.status = 'stopped';
        job.current = 'Stopped by user during automatic recovery';
        await this.save(job);
        return false;
      }
      await sleep(Math.min(10_000, deadline - Date.now()));
    }
    return true;
  }

  async run(job) {
    const rowKeys = await reconcileDataFile(job.dataFile);
    if (job.collectedRows !== rowKeys.size) {
      job.collectedRows = rowKeys.size;
      await this.save(job);
    }
    const profile = path.join(job.dir, 'browser-profile');
    const channel = job.config.browser === 'chrome' ? 'chrome' : 'msedge';
    let context;
    try {
      context = await chromium.launchPersistentContext(profile, {
        channel, headless: false, args: job.config.background ? ['--start-minimized'] : [], viewport: { width: 1440, height: 980 }, locale: 'en-IN',
      });
    } catch (error) {
      if (/executable|browser.*not found|failed to launch/i.test(error.message)) {
        throw new Error(`${job.config.browser === 'chrome' ? 'Google Chrome' : 'Microsoft Edge'} is not installed or could not be started. Choose the other installed browser and try again.`);
      }
      throw error;
    }
    const page = context.pages()[0] || await context.newPage();
    job.status = 'running';
    await this.save(job);
    try {
      await page.goto(SOURCE_URL, { waitUntil: 'domcontentloaded', timeout: 60_000 });
      await assertSafePage(page);
      await waitForDashboardReady(page);
      let selectors = await resolveDashboardSelectors(page);
      await selectDashboardOption(page, selectors.unit, 'A');
      await selectDashboardOption(page, selectors.yearType, 'C');
      await selectDashboardOption(page, selectors.xAxis, { label: 'Month Wise' });
      const selectedStates = await dashboardOptions(page, selectors.state);
      const allowedStates = job.config.states.includes('ALL') ? selectedStates : selectedStates.filter((s) => job.config.states.includes(s.value));
      if (!allowedStates.length) throw new Error('None of the requested states are currently available on the Vaahan dashboard.');
      let ordinal = 0;
      for (const state of allowedStates) {
        selectors = await resolveDashboardSelectors(page);
        await selectDashboardOption(page, selectors.state, state.value);
        await waitForRtos(page, selectors.rto, state.value);
        await assertSafePage(page);
        selectors = await resolveDashboardSelectors(page);
        const availableRtos = await dashboardOptions(page, selectors.rto, true);
        const aggregateRto = availableRtos.find((rto) => rto.value === '-1' && /all/i.test(rto.text)) || availableRtos.find((rto) => rto.value === '-1');
        const rtos = job.config.rtoMode === 'state_total' ? (aggregateRto ? [{ ...aggregateRto, text: 'All RTOs (state total)' }] : []) : availableRtos.filter((rto) => rto.value !== '-1');
        if (!rtos.length) throw new Error(`No public RTOs were returned for ${state.text}.`);
        for (const rto of rtos) {
          for (const segmentId of job.config.segments) {
            const segment = VEHICLE_SEGMENTS.find((s) => s.id === segmentId);
            for (const year of [...new Set(estimateJob(job.config).periods.map((p) => p.year))]) {
              ordinal += 1;
              if (ordinal <= job.completedReports) continue;
              if (job.stopRequested) {
                job.status = 'stopped'; job.current = 'Stopped by user'; await this.save(job); return;
              }
              if (!await this.waitForDailyCapacity(job)) return;
              job.current = `${state.text} · ${rto.text} · ${segment.label} · ${year}`;
              await this.save(job);
              selectors = await resolveDashboardSelectors(page);
              await selectDashboardOption(page, selectors.rto, rto.value);
              await selectDashboardOption(page, selectors.year, String(year));
              await selectDashboardOption(page, selectors.segment, segment.group);
              const breakdown = BREAKDOWNS.find((b) => b.id === job.config.breakdown);
              await selectDashboardOption(page, selectors.yAxis, { label: breakdown.yAxis });
              const reportStartedAt = Date.now();
              const adaptiveDelay = job.adaptiveDelaySeconds || 0;
              await randomPause(job.config.minDelaySeconds + adaptiveDelay, (job.config.maxDelaySeconds || job.config.minDelaySeconds + 30) + adaptiveDelay);
              if (job.stopRequested) {
                job.status = 'stopped'; job.current = 'Stopped by user before the next report request'; await this.save(job); return;
              }
              const refreshStartedAt = Date.now();
              await refreshDashboard(page);
              await assertSafePage(page);
              const raw = await extractReport(page, breakdown.yAxis);
              updateAdaptivePacing(job, (Date.now() - refreshStartedAt) / 1000);
              const records = shapeRecords(raw, { job, state, rto, segment, year, breakdown });
              const newRowCount = countNewRows(records, rowKeys);
              if (job.collectedRows + newRowCount > 100_000) throw new Error('Actual output would exceed 100,000 rows. The job was stopped before writing them.');
              const appendedRows = await appendUniqueNdjson(job.dataFile, records, rowKeys);
              await incrementUsage();
              const reportSeconds = (Date.now() - reportStartedAt) / 1000;
              job.averageReportSeconds = rollingAverage(job.averageReportSeconds, job.completedReports, reportSeconds);
              job.completedReports = ordinal;
              job.collectedRows += appendedRows;
              await this.save(job);
            }
          }
        }
      }
      job.status = 'complete'; job.current = 'Collection complete'; await this.save(job);
    } finally {
      await context.close().catch(() => {});
    }
  }

  async save(job) {
    job.updatedAt = new Date().toISOString();
    await fs.writeFile(path.join(job.dir, 'job.json'), JSON.stringify({ ...job, dir: undefined, dataFile: undefined }, null, 2));
  }

  async waitForDailyCapacity(job) {
    while (true) {
      const today = indiaDate();
      const usage = await readJson(USAGE_FILE, { date: today, count: 0 });
      const count = usage.date === today ? usage.count : 0;
      if (count < job.config.maxDailyReports) {
        if (job.status === 'waiting') {
          job.status = 'running';
          job.current = 'Daily collection window reopened; continuing automatically from the checkpoint.';
          await this.save(job);
        }
        return true;
      }
      job.status = 'waiting';
      job.current = `Daily safety cap (${job.config.maxDailyReports}) reached. The companion will continue automatically after midnight India time; keep this computer awake.`;
      await this.save(job);
      while (indiaDate() === today) {
        if (job.stopRequested) {
          job.status = 'stopped';
          job.current = 'Stopped by user while waiting for the next daily window';
          await this.save(job);
          return false;
        }
        await sleep(60_000);
      }
    }
  }
}

async function extractReport(page, heading) {
  let result;
  for (let attempt = 0; attempt < 15; attempt += 1) {
    result = await page.locator('table').evaluateAll((tables, expected) => {
      const candidates = tables.filter((table) => table.rows.length > 1 && table.innerText.toLowerCase().includes(expected.toLowerCase()));
      const table = candidates.at(-1);
      if (!table) return { headers: [], rows: [], diagnostics: { tables: tables.length, candidates: 0, previews: tables.filter((item) => item.rows.length > 1).slice(-3).map((item) => item.innerText.slice(0, 80).replace(/\s+/g, ' ')) } };
      const headers = [...table.querySelectorAll('thead tr:last-child th')].map((cell) => cell.textContent.trim());
      const rows = [...table.querySelectorAll('tbody tr')].map((row) => [...row.querySelectorAll('td')].map((cell) => cell.textContent.trim()));
      return { headers, rows, diagnostics: { tables: tables.length, candidates: candidates.length, tableRows: table.rows.length, bodyRows: rows.length, preview: table.innerText.slice(0, 160).replace(/\s+/g, ' ') } };
    }, heading);
    if (result.rows.length) return result;
    await page.waitForTimeout(2000);
    await assertSafePage(page);
  }
  throw new Error(`No report rows were found after waiting for Vaahan (${JSON.stringify(result.diagnostics)}). The job was paused safely.`);
}

async function refreshDashboard(page) {
  const responsePromise = page.waitForResponse((response) => response.request().method() === 'POST' && response.url().includes('reportview.xhtml'), { timeout: 45_000 });
  await page.getByRole('button', { name: 'Refresh', exact: true }).click();
  const response = await responsePromise;
  if (response.status() === 429) throw new Error('Vaahan reported a rate limit. The job was paused.');
  if (response.status() >= 500) throw new Error(`Vaahan temporarily returned server error ${response.status()}.`);
  await page.waitForFunction(() => {
    const jqueryIdle = !window.jQuery || window.jQuery.active === 0;
    const visibleBlocker = [...document.querySelectorAll('.ui-blockui')]
      .some((element) => getComputedStyle(element).display !== 'none' && getComputedStyle(element).visibility !== 'hidden' && element.getBoundingClientRect().width > 0);
    return jqueryIdle && !visibleBlocker;
  }, null, { timeout: 45_000 });
  await page.waitForTimeout(900);
}

function shapeRecords(raw, { job, state, rto, segment, year, breakdown }) {
  const periods = estimateJob(job.config).periods.filter((p) => p.year === year);
  const numeric = (value) => Number(String(value || '0').replaceAll(',', '')) || 0;
  const sampleWidth = raw.rows.find((row) => row.length)?.length || 0;
  const monthOffset = Math.max(0, sampleWidth - raw.headers.length - 1);
  const dimensionIndex = Math.max(0, monthOffset - 1);
  const monthColumns = raw.headers.map((h, i) => ({ h, i: i + monthOffset })).filter(({ h }) => /jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/i.test(h));
  const rows = [];
  for (const period of periods) {
    const indices = job.config.periodMode === 'month'
      ? monthColumns.filter(({ h }) => h.toLowerCase().startsWith(['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'][period.period - 1])).map((c) => c.i)
      : monthColumns.slice((period.period - 1) * 3, period.period * 3).map((c) => c.i);
    for (const rawRow of raw.rows) {
      const dimension = rawRow[dimensionIndex] || 'Total';
      const registrations = indices.length ? indices.reduce((sum, i) => sum + numeric(rawRow[i]), 0) : 0;
      rows.push({ period: period.label, state: state.text, state_code: state.value, rto: rto.text, rto_code: rto.value,
        vehicle_segment: segment.label, breakdown: breakdown.label, dimension, registrations,
        source_url: SOURCE_URL, collected_at_utc: new Date().toISOString() });
    }
  }
  if (breakdown.id !== 'total') return rows;
  const totals = new Map();
  for (const row of rows) totals.set(row.period, (totals.get(row.period) || 0) + row.registrations);
  return [...totals].map(([period, registrations]) => ({ ...rows.find((r) => r.period === period), dimension: 'Total', registrations }));
}

async function dashboardOptions(page, selector, includeAggregate = false) {
  return page.locator(selector).evaluate((select, includeAggregate) => [...select.options]
    .filter((o) => o.value && (includeAggregate || o.value !== '-1')).map((o) => ({ value: o.value, text: o.textContent.trim() })), includeAggregate);
}
async function resolveDashboardSelectors(page) {
  const selectors = await page.locator('select').evaluateAll((selects) => {
    const options = (select) => [...select.options].map((option) => ({ value: option.value, text: option.textContent.trim() }));
    const hasValue = (select, value) => options(select).some((option) => option.value === value);
    const hasText = (select, value) => options(select).some((option) => option.text.toLowerCase() === value.toLowerCase());
    const selector = (select) => select?.id ? `#${CSS.escape(select.id)}` : null;
    const find = (predicate) => selector(selects.find(predicate));
    return {
      unit: find((select) => hasText(select, 'Actual Value') && hasText(select, 'In Thousand')),
      state: find((select) => hasValue(select, 'AN') && hasValue(select, 'AP') && hasValue(select, 'CH')),
      rto: find((select) => options(select).some((option) => /Vahan4 Running Office/i.test(option.text))),
      yAxis: find((select) => hasValue(select, 'Maker') && hasValue(select, 'Fuel') && hasValue(select, 'Vehicle Class')),
      xAxis: find((select) => hasValue(select, 'Month Wise') && hasValue(select, 'Financial Year')),
      yearType: find((select) => hasValue(select, 'F') && hasValue(select, 'C') && hasText(select, 'Select')),
      year: find((select) => hasText(select, 'Select Year') && options(select).some((option) => /^20\d{2}$/.test(option.value))),
      segment: find((select) => options(select).some((option) => option.value.startsWith('2W|')) && options(select).some((option) => option.value.startsWith('TR|'))),
    };
  });
  const missing = Object.entries(selectors).filter(([, selector]) => !selector).map(([name]) => name);
  if (missing.length) throw new Error(`Vaahan dashboard controls changed (${missing.join(', ')} not found). The job was paused before making report requests.`);
  return selectors;
}
async function waitForDashboardReady(page) {
  await page.waitForFunction(() => [...document.querySelectorAll('select option')]
    .some((option) => String(option.value).startsWith('TR|')), null, { timeout: 45_000 }).catch(() => {
    throw new Error('Vaahan did not finish loading its dashboard controls. The job was paused before making report requests.');
  });
}
async function selectDashboardOption(page, selector, choice) {
  const locator = page.locator(selector);
  const matches = async () => locator.evaluate((select, expected) => {
    const selected = select.selectedOptions[0];
    return typeof expected === 'string' ? select.value === expected : selected?.textContent.trim() === expected.label;
  }, choice);
  await locator.selectOption(choice, { force: true });
  await page.waitForTimeout(1600);
  if (await matches()) return;
  await locator.selectOption(choice, { force: true });
  await page.waitForTimeout(2200);
  if (!await matches()) throw new Error(`Vaahan reset a dashboard filter (${selector}). The job was paused before refreshing the report.`);
}
async function waitForRtos(page, selector, stateCode) {
  await page.waitForTimeout(1200);
  await page.waitForFunction(({ selector: css }) => {
    const select = document.querySelector(css);
    return select && [...select.options].some((option) => option.value && option.value !== '-1');
  }, { selector }, { timeout: 30_000 }).catch(() => {
    throw new Error(`Vaahan did not return RTO options for state ${stateCode}. The job was paused safely.`);
  });
}
async function assertSafePage(page) {
  const snapshot = await page.evaluate(() => ({ title: document.title, text: document.body.innerText.slice(0, 12000).toLowerCase() }));
  if (/captcha|verify you are human|access denied/.test(snapshot.text)) throw new Error('CAPTCHA or access challenge detected. No bypass was attempted.');
  if (/too many requests|rate limit|temporarily blocked/.test(snapshot.text)) throw new Error('Vaahan reported a rate limit. The job was paused.');
  if (!/vahan/.test((snapshot.title || '').toLowerCase())) throw new Error('Unexpected page. The job was paused for review.');
}
async function randomPause(min, max) { await new Promise((resolve) => setTimeout(resolve, (min + Math.random() * (max - min)) * 1000)); }
async function sleep(ms) { await new Promise((resolve) => setTimeout(resolve, ms)); }
async function reconcileDataFile(file) {
  const text = await fs.readFile(file, 'utf8').catch(() => '');
  const lines = text.split(/\r?\n/).filter(Boolean);
  const unique = new Map();
  for (const line of lines) {
    const record = JSON.parse(line);
    const key = rowKey(record);
    if (!unique.has(key)) unique.set(key, record);
  }
  if (unique.size !== lines.length) {
    const repaired = [...unique.values()].map((record) => JSON.stringify(record)).join('\n');
    await fs.writeFile(file, repaired ? `${repaired}\n` : '');
  }
  return new Set(unique.keys());
}
async function appendUniqueNdjson(file, records, existingKeys) {
  const unique = [];
  for (const record of records) {
    const key = rowKey(record);
    if (existingKeys.has(key)) continue;
    existingKeys.add(key);
    unique.push(record);
  }
  if (unique.length) await fs.appendFile(file, unique.map((record) => JSON.stringify(record)).join('\n') + '\n');
  return unique.length;
}
function countNewRows(records, existingKeys) {
  const pending = new Set();
  for (const record of records) {
    const key = rowKey(record);
    if (!existingKeys.has(key)) pending.add(key);
  }
  return pending.size;
}
function rowKey(record) {
  return [record.period, record.state_code, record.rto_code, record.vehicle_segment, record.breakdown, record.dimension].map((value) => String(value ?? '')).join('\u001f');
}
function rollingAverage(previous, completedReports, nextSeconds) {
  if (!Number.isFinite(previous) || completedReports <= 0) return Number(nextSeconds.toFixed(1));
  return Number((((previous * completedReports) + nextSeconds) / (completedReports + 1)).toFixed(1));
}
function updateAdaptivePacing(job, refreshSeconds) {
  const current = job.adaptiveDelaySeconds || 0;
  if (refreshSeconds > 20) job.adaptiveDelaySeconds = Math.min(45, current + 15);
  else if (refreshSeconds < 10) job.adaptiveDelaySeconds = Math.max(0, current - 5);
}
function isRecoverableError(error) {
  const message = String(error?.message || error);
  if (/captcha|access challenge|access denied|rate limit|too many requests|output would exceed|not installed|controls changed|unexpected page/i.test(message)) return false;
  return /timeout|target page|context.*closed|browser.*closed|net::err_|navigation|econnreset|socket hang up|no report rows|did not finish loading|did not return rto|reset a dashboard filter|server error 5\d\d|failed to launch/i.test(message);
}
async function readJson(file, fallback) { try { return JSON.parse(await fs.readFile(file, 'utf8')); } catch { return fallback; } }
function indiaDate() { return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(new Date()); }
async function incrementUsage() { const today = indiaDate(); const u = await readJson(USAGE_FILE, { date: today, count: 0 }); const next = { date: today, count: u.date === today ? u.count + 1 : 1 }; await fs.mkdir(path.dirname(USAGE_FILE), { recursive: true }); await fs.writeFile(USAGE_FILE, JSON.stringify(next, null, 2)); }
function compactEstimate(e) { return { estimatedRows: e.estimatedRows, reportRequests: e.reportRequests, estimatedDays: e.estimatedDays, estimatedPacingHours: e.estimatedPacingHours, estimatedActiveSeconds: e.estimatedActiveSeconds, estimatedActiveHours: e.estimatedActiveHours, rtoCount: e.rtoCount, reportingUnits: e.reportingUnits }; }
function publicJob(job) {
  const remainingReports = Math.max(0, (job.estimate?.reportRequests || 0) - (job.completedReports || 0));
  const plannedSeconds = job.estimate?.reportRequests ? (job.estimate.estimatedActiveSeconds || job.estimate.estimatedActiveHours * 3600 || job.estimate.reportRequests * (((job.config.minDelaySeconds + (job.config.maxDelaySeconds || job.config.minDelaySeconds + 30)) / 2) + 8)) / job.estimate.reportRequests : 0;
  const averageReportSeconds = job.averageReportSeconds || plannedSeconds;
  return {
    id: job.id, status: job.status, createdAt: job.createdAt, updatedAt: job.updatedAt, config: job.config, estimate: job.estimate,
    completedReports: job.completedReports, collectedRows: job.collectedRows, current: job.current, error: job.error,
    autoRecoveries: job.autoRecoveries || 0, averageReportSeconds: job.averageReportSeconds || null,
    adaptiveDelaySeconds: job.adaptiveDelaySeconds || 0, estimatedRemainingActiveSeconds: Math.round(remainingReports * averageReportSeconds),
    estimatedRemainingDays: remainingReports ? Math.max(1, Math.ceil(remainingReports / job.config.maxDailyReports)) : 0,
  };
}

export { isRecoverableError, publicJob, rowKey, rollingAverage };
