import json, sys
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

job_path, data_path, output_path = sys.argv[1:4]
with open(job_path, encoding='utf-8') as f: job = json.load(f)
rows = []
try:
    with open(data_path, encoding='utf-8') as f:
        rows = [json.loads(line) for line in f if line.strip()]
except FileNotFoundError: pass
if len(rows) > 2000: raise SystemExit('PDF detail export is capped at 2,000 rows')

styles = getSampleStyleSheet()
doc = SimpleDocTemplate(output_path, pagesize=landscape(A4), rightMargin=10*mm, leftMargin=10*mm, topMargin=12*mm, bottomMargin=12*mm,
                        title='Vaahan public registration export', author='Vaahan Safe Data Collector')
story = [Paragraph('Vaahan public registration export', styles['Title']), Spacer(1, 5*mm)]
summary = [
    ['Job', job['id']], ['Status', job['status']], ['Segments', ', '.join(job['config']['segments'])],
    ['Breakdown', job['config']['breakdown']], ['Rows', str(len(rows))],
    ['Source', 'https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml'],
    ['Note', 'Registration counts are a sales proxy; vehicle model is not exposed by the public report.']]
t = Table(summary, colWidths=[38*mm, 215*mm])
t.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),colors.HexColor('#D9E8DF')),('TEXTCOLOR',(0,0),(0,-1),colors.HexColor('#173F35')),
                       ('FONTNAME',(0,0),(0,-1),'Helvetica-Bold'),('GRID',(0,0),(-1,-1),0.3,colors.HexColor('#AAB7B0')),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTSIZE',(0,0),(-1,-1),8)]))
story += [t, PageBreak()]
headers = ['Period','State','RTO','Segment','Breakdown','Dimension','Registrations']
data = [headers] + [[r.get('period',''), r.get('state',''), r.get('rto',''), r.get('vehicle_segment',''), r.get('breakdown',''), r.get('dimension',''), f"{r.get('registrations',0):,}"] for r in rows]
table = Table(data, repeatRows=1, colWidths=[23*mm,39*mm,44*mm,34*mm,34*mm,53*mm,25*mm])
table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#173F35')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
                           ('GRID',(0,0),(-1,-1),0.2,colors.HexColor('#C9D2CD')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F3F7F5')]),
                           ('ALIGN',(-1,1),(-1,-1),'RIGHT'),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTSIZE',(0,0),(-1,-1),6.5)]))
story.append(table)
doc.build(story)
