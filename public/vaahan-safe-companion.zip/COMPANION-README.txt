VAAHAN SAFE DATA COLLECTOR — WINDOWS COMPANION

This local companion is required because a public static website cannot safely
run a persistent Chrome or Edge browser on a visitor's computer.

Requirements
- Windows 10 or 11
- Node.js 20 or newer from https://nodejs.org/
- Microsoft Edge or Google Chrome installed
- Optional for PDF export: Python 3 with the reportlab package

Setup
1. Extract the entire ZIP to a normal folder.
2. Right-click install.ps1 and choose Run with PowerShell. This installs the
   exact dependency versions recorded in package-lock.json and skips browser
   downloads; your installed Edge or Chrome is used.
3. Run start.ps1 and leave the PowerShell window open.
4. The complete local control room opens automatically in Microsoft Edge at
   http://127.0.0.1:4173. It needs no pairing or local-network permission.
5. Choose the data scope and preferred format. Leave automatic download
   selected to save the result when collection completes.
6. Optional: choose Use hosted planner in the local page. Edge may request
   local-network permission before the hosted planner can control the companion.

Security design
- The service listens only on 127.0.0.1 and is not exposed to the internet.
- A random pairing code and session token are created on every restart.
- Only the published planner and the same-origin local control room are allowed;
  the hosted planner must present the pairing code before receiving a token.
- One-click pairing carries the code only in a URL fragment, which is not sent
  to GitHub and is removed from the address bar before the session is requested.
- Mutating requests require JSON, the session token, and pass a local rate limit.
- Pairing attempts, export requests, and request-body sizes are bounded.
- Client errors do not reveal local filesystem paths.
- One scrape job can run at a time. CAPTCHA or access challenges pause the job.
- No passwords, vehicle-level records, proxies, CAPTCHA solving, or bypasses.

Background collection
Vaahan rejects true headless browser access. To respect that control, background
mode uses a normal browser minimized to the taskbar; it may briefly appear while
starting. Choose Visible troubleshooting only when you need to observe an issue.
The Balanced preset uses a randomized 30–45 second pause, one report at a time,
and a ceiling of 100 reports per India day. Conservative mode uses 45–75 seconds
and 80 reports per day. State totals are substantially faster than individual
RTO detail because they combine all RTOs within each state.

Every completed report is checkpointed. If the daily ceiling is reached, the
companion changes to Waiting and automatically continues after midnight India
time while the computer remains awake and start.ps1 remains open. CAPTCHA,
access restrictions, browser closure, power-off, or dashboard changes still
require a safe pause. Closing start.ps1 stops the companion; completed data and
checkpoints remain in the local data folder.

Reliability and timing
- Report refreshes wait for Vaahan's actual response and completed page update,
  replacing a fixed post-click timer.
- Temporary browser, network, or dashboard timeouts retry twice after 45 and 90
  seconds, reopening from the last completed checkpoint.
- CAPTCHA, access restrictions, rate limits, output limits, and genuine control
  changes never auto-retry.
- Checkpoint files are reconciled on resume so an interrupted write cannot add
  duplicate analytical rows to exports.
- If Vaahan report refreshes become slow, the companion adds up to 45 seconds of
  adaptive pause. The job monitor shows observed time remaining and recoveries.

Downloads
- XLSX: Summary and Data worksheets for Excel or Google Sheets.
- CSV: flat data for Power BI, databases, Python, or R.
- PDF: compact human-readable output, limited to 2,000 rows.
- Partial exports: available from the job monitor while a job is in progress.

This independent project is for educational, research, and analytical use. It
is not affiliated with or endorsed by MoRTH, NIC, Parivahan, or Vaahan. Users
must comply with current site terms, access controls, and applicable law.
