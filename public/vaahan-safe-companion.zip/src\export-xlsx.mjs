import fs from 'node:fs/promises';
import ExcelJS from 'exceljs';
import { SOURCE_URL } from './catalog.mjs';

const HEADERS = ['period','state','state_code','rto','rto_code','vehicle_segment','breakdown','dimension','registrations','source_url','collected_at_utc'];

export async function exportXlsx(job, outputPath) {
  const records = await readRecords(job.dataFile);
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Vaahan Safe Data Collector';
  workbook.created = new Date();
  const summary = workbook.addWorksheet('Summary', { views: [{ state: 'frozen', ySplit: 3 }] });
  const data = workbook.addWorksheet('Data', { views: [{ state: 'frozen', xSplit: 2, ySplit: 1 }] });

  summary.mergeCells('A1:F1');
  summary.getCell('A1').value = 'Vaahan public registration export';
  summary.addRows([[],
    ['Setting','Value'],['Source',SOURCE_URL],['Job ID',job.id],
    ['Vehicle segments',job.config.segments.join(', ')],['Breakdown',job.config.breakdown],
    ['States',job.config.states.includes('ALL') ? 'All Vaahan states / all RTOs' : job.config.states.join(', ')],
    ['Geography detail',job.config.rtoMode === 'state_total' ? 'State totals (all RTOs combined)' : 'Individual RTO detail'],
    ['Timeline',`${job.config.startYear}/${job.config.startPeriod} to ${job.config.endYear}/${job.config.endPeriod} (${job.config.periodMode})`],
    ['Browser / mode',`${job.config.browser === 'chrome' ? 'Google Chrome' : 'Microsoft Edge'} / ${job.config.background ? 'background' : 'visible'}`],
    ['Rows collected',records.length],['Reports completed',job.completedReports],
    ['Automatic recoveries',job.autoRecoveries || 0],
    ['Observed average/report',job.averageReportSeconds ? `${job.averageReportSeconds} seconds` : 'Not available'],
    ['Collection policy',`${job.config.minDelaySeconds}-${job.config.maxDelaySeconds || job.config.minDelaySeconds + 30}s randomized delay; max ${job.config.maxDailyReports} reports/day; concurrency 1`],
    ['Important note','Registrations are a sales proxy. This public report does not expose vehicle model.'],
  ]);
  summary.getCell('A1').font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 16, name: 'Arial' };
  summary.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF173F35' } };
  summary.getRow(1).height = 32;
  for (const cell of [summary.getCell('A3'), summary.getCell('B3')]) {
    cell.font = { bold: true, color: { argb: 'FF173F35' }, name: 'Arial', size: 10 };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9E8DF' } };
  }
  summary.getColumn(1).width = 28;
  summary.getColumn(2).width = 72;
  summary.eachRow((row) => { row.alignment = { vertical: 'top', wrapText: true }; if (row.number > 1) row.font = { name: 'Arial', size: 10 }; });

  data.columns = HEADERS.map((header) => ({ header, key: header, width: header === 'source_url' ? 64 : header === 'rto' ? 34 : header === 'collected_at_utc' ? 22 : 20 }));
  for (const record of records) {
    const row = {};
    for (const header of HEADERS) row[header] = header === 'collected_at_utc' ? new Date(record[header]) : safeSpreadsheetValue(record[header]);
    data.addRow(row);
  }
  data.autoFilter = { from: 'A1', to: 'K1' };
  data.getColumn('registrations').numFmt = '#,##0';
  data.getColumn('collected_at_utc').numFmt = 'yyyy-mm-dd hh:mm';
  data.getRow(1).eachCell((cell) => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, name: 'Arial', size: 10 };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF173F35' } };
  });
  data.eachRow((row, number) => { if (number > 1) row.font = { name: 'Arial', size: 10 }; });
  await workbook.xlsx.writeFile(outputPath);
}

export async function readRecords(file) {
  const text = await fs.readFile(file, 'utf8').catch(() => '');
  const unique = new Map();
  for (const line of text.split(/\r?\n/).filter(Boolean)) {
    const record = JSON.parse(line);
    const key = [record.period, record.state_code, record.rto_code, record.vehicle_segment, record.breakdown, record.dimension].map((value) => String(value ?? '')).join('\u001f');
    if (!unique.has(key)) unique.set(key, record);
  }
  return [...unique.values()];
}

export async function exportCsv(job, outputPath) {
  const records = await readRecords(job.dataFile);
  const csv = [HEADERS.join(','), ...records.map((record) => HEADERS.map((header) => quote(record[header])).join(','))].join('\n');
  await fs.writeFile(outputPath, csv + '\n');
}

function safeSpreadsheetValue(value) {
  return typeof value === 'string' && /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
}

function quote(value) {
  const text = String(safeSpreadsheetValue(value) ?? '');
  return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}
