import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { isRecoverableError, rollingAverage, rowKey } from '../src/job-manager.mjs';
import { readRecords } from '../src/export-xlsx.mjs';

test('temporary browser failures recover but safeguards never auto-retry', () => {
  assert.equal(isRecoverableError(new Error('locator.selectOption: Timeout 30000ms exceeded')), true);
  assert.equal(isRecoverableError(new Error('Vaahan temporarily returned server error 503.')), true);
  assert.equal(isRecoverableError(new Error('CAPTCHA or access challenge detected. No bypass was attempted.')), false);
  assert.equal(isRecoverableError(new Error('Vaahan reported a rate limit. The job was paused.')), false);
  assert.equal(isRecoverableError(new Error('Vaahan dashboard controls changed (year not found).')), false);
});

test('row identity ignores collection time but preserves analytical dimensions', () => {
  const base = { period:'Jul 2026', state_code:'CH', rto_code:'-1', vehicle_segment:'Tractors', breakdown:'Total registrations', dimension:'Total' };
  assert.equal(rowKey({ ...base, collected_at_utc:'2026-08-08T00:00:00Z' }), rowKey({ ...base, collected_at_utc:'2026-08-08T01:00:00Z' }));
  assert.notEqual(rowKey(base), rowKey({ ...base, dimension:'Diesel' }));
});

test('exports remove duplicated checkpoint rows', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'vaahan-reliability-'));
  const file = path.join(directory, 'data.ndjson');
  const row = { period:'Jul 2026', state_code:'CH', rto_code:'-1', vehicle_segment:'Tractors', breakdown:'Total registrations', dimension:'Total', registrations:4580 };
  await fs.writeFile(file, `${JSON.stringify(row)}\n${JSON.stringify({ ...row, collected_at_utc:'later' })}\n`);
  const records = await readRecords(file);
  assert.equal(records.length, 1);
  assert.equal(records[0].registrations, 4580);
  await fs.rm(directory, { recursive:true, force:true });
});

test('observed report timing uses a stable rolling average', () => {
  assert.equal(rollingAverage(null, 0, 40), 40);
  assert.equal(rollingAverage(40, 1, 60), 50);
});
