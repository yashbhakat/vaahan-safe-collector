$ErrorActionPreference = 'Stop'
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
  Write-Host 'Node.js 20 or newer is required.' -ForegroundColor Yellow
  Write-Host 'Download it from https://nodejs.org/en/download and run this installer again.'
  exit 1
}
$major = [int]((& $node.Source --version).TrimStart('v').Split('.')[0])
if ($major -lt 20) { throw 'Node.js 20 or newer is required.' }
$npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
if (-not $npm) { throw 'npm was not found next to Node.js. Reinstall the standard Node.js package.' }
$env:PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD = '1'
Write-Host 'Installing locked, free collector dependencies…'
& $npm.Source ci --omit=dev --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed ($LASTEXITCODE)." }
Write-Host 'Installation complete. Run start.ps1, then return to the hosted planner.' -ForegroundColor Green
