import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { exportCsv, exportXlsx } from '../src/export-xlsx.mjs';

const dir = path.join(process.cwd(), 'outputs', 'verification');
await fs.mkdir(dir, { recursive: true });
const job = {
  id: 'sample-verification', status: 'complete', completedReports: 1, collectedRows: 2, dir,
  dataFile: path.join(dir, 'sample.ndjson'),
  config: { segments:['TR'],states:['DL'],breakdown:'total',periodMode:'month',startYear:2026,startPeriod:1,endYear:2026,endPeriod:2,minDelaySeconds:45,maxDailyReports:80 },
};
const rows = [
  {period:'Jan 2026',state:'Delhi',state_code:'DL',rto:'Sample RTO',rto_code:'DL01',vehicle_segment:'Tractors',breakdown:'Total registrations',dimension:'Total',registrations:123,source_url:'https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml',collected_at_utc:new Date().toISOString()},
  {period:'Feb 2026',state:'Delhi',state_code:'DL',rto:'Sample RTO',rto_code:'DL01',vehicle_segment:'Tractors',breakdown:'Total registrations',dimension:'Total',registrations:137,source_url:'https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml',collected_at_utc:new Date().toISOString()},
];
await fs.writeFile(job.dataFile, rows.map(JSON.stringify).join('\n') + '\n');
await fs.writeFile(path.join(dir, 'job.json'), JSON.stringify(job, null, 2));
await exportXlsx(job, path.join(dir, 'sample.xlsx'));
await exportCsv(job, path.join(dir, 'sample.csv'));
await new Promise((resolve, reject) => {
  const python = process.env.PYTHON || 'python';
  const child = spawn(python, [path.join(process.cwd(),'scripts','export_pdf.py'),path.join(dir,'job.json'),job.dataFile,path.join(dir,'sample.pdf')], { windowsHide:true });
  let error=''; child.stderr.on('data',(d)=>error+=d); child.on('error',reject); child.on('close',(code)=>code===0?resolve():reject(new Error(error || `PDF export failed (${code})`)));
});
console.log(`Verified XLSX, CSV and PDF exports in ${dir}`);
