import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { chromium } from "playwright";

const URL = "https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml";
const ROOT = process.cwd();
const DATA_DIR = path.join(ROOT, "data");
const CSV_PATH = path.join(DATA_DIR, "tractor_sales.csv");
const CHECKPOINT_PATH = path.join(DATA_DIR, "checkpoint.json");
const USAGE_PATH = path.join(DATA_DIR, "daily-usage.json");
const PROFILE_DIR = path.join(ROOT, ".browser-profile");
const RUN = process.argv.includes("--run");

const currentYear = new Date().getFullYear();
const START_YEAR = integerEnv("VAAHAN_START_YEAR", currentYear - 4);
const END_YEAR = integerEnv("VAAHAN_END_YEAR", currentYear);
const MIN_DELAY = Math.max(45_000, integerEnv("VAAHAN_MIN_DELAY_MS", 45_000));
const MAX_DELAY = Math.max(MIN_DELAY, integerEnv("VAAHAN_MAX_DELAY_MS", 75_000));
const DAILY_LIMIT = Math.min(80, Math.max(1, integerEnv("VAAHAN_DAILY_LIMIT", 80)));

const CSV_HEADERS = [
  "calendar_year", "state", "state_code", "rto", "rto_code", "maker", "model",
  "product_granularity", "vehicle_group", "lmv", "mmv", "lgv", "mgv", "hgv",
  "oth", "total", "source_url", "collected_at_utc"
];

if (!RUN) {
  console.log(JSON.stringify({
    mode: "plan-only",
    source: URL,
    years: [START_YEAR, END_YEAR],
    estimatedRtos: 1465,
    estimatedReportRefreshes: 1465 * (END_YEAR - START_YEAR + 1),
    dailyLimit: DAILY_LIMIT,
    randomizedDelayMs: [MIN_DELAY, MAX_DELAY],
    productGranularity: "maker (the public report does not expose model)"
  }, null, 2));
  process.exit(0);
}

await fs.mkdir(DATA_DIR, { recursive: true });
await ensureCsv();
const checkpoint = await readJson(CHECKPOINT_PATH, { stateIndex: 0, rtoIndex: 0, yearIndex: 0 });
const usage = await loadUsage();
enforceDailyLimit(usage);

const context = await chromium.launchPersistentContext(PROFILE_DIR, {
  channel: "msedge",
  headless: false,
  viewport: { width: 1440, height: 1000 },
  locale: "en-IN"
});
const page = context.pages()[0] || await context.newPage();
let stopping = false;
process.on("SIGINT", () => { stopping = true; });

try {
  await page.goto(URL, { waitUntil: "domcontentloaded", timeout: 60_000 });
  await assertSafePage(page);
  await configureTractorMakerReport(page);

  const states = await selectOptions(page, "#j_idt37_input", "-1");
  for (let si = checkpoint.stateIndex; si < states.length && !stopping; si++) {
    const state = states[si];
    await page.locator("#j_idt37_input").selectOption(state.value);
    await page.waitForTimeout(2_000);
    await assertSafePage(page);
    const rtos = await selectOptions(page, "#selectedRto_input", "-1");

    const startRto = si === checkpoint.stateIndex ? checkpoint.rtoIndex : 0;
    for (let ri = startRto; ri < rtos.length && !stopping; ri++) {
      const rto = rtos[ri];
      await page.locator("#selectedRto_input").selectOption(rto.value);
      const years = Array.from({ length: END_YEAR - START_YEAR + 1 }, (_, i) => START_YEAR + i);
      const startYear = si === checkpoint.stateIndex && ri === checkpoint.rtoIndex
        ? checkpoint.yearIndex : 0;

      for (let yi = startYear; yi < years.length && !stopping; yi++) {
        enforceDailyLimit(usage);
        const year = years[yi];
        await page.locator("#selectedYear_input").selectOption(String(year));
        await randomizedPause();
        await page.getByRole("button", { name: "Refresh", exact: true }).click();
        await page.waitForTimeout(3_000);
        await assertSafePage(page);

        const rows = await extractAllPages(page);
        const collectedAt = new Date().toISOString();
        const records = rows.map(row => ({
          calendar_year: year,
          state: state.text,
          state_code: state.value,
          rto: rto.text,
          rto_code: rto.value,
          maker: row[1],
          model: "",
          product_granularity: "maker",
          vehicle_group: "TRACTOR",
          lmv: number(row[2]), mmv: number(row[3]), lgv: number(row[4]),
          mgv: number(row[5]), hgv: number(row[6]), oth: number(row[7]),
          total: number(row[8]),
          source_url: URL,
          collected_at_utc: collectedAt
        }));
        await appendCsv(records);
        usage.count += 1;
        await fs.writeFile(USAGE_PATH, JSON.stringify(usage, null, 2));
        await saveCheckpoint({ stateIndex: si, rtoIndex: ri, yearIndex: yi + 1 });
        console.log(`${state.text} | ${rto.text} | ${year}: ${records.length} maker rows`);
      }
      await saveCheckpoint({ stateIndex: si, rtoIndex: ri + 1, yearIndex: 0 });
    }
    await saveCheckpoint({ stateIndex: si + 1, rtoIndex: 0, yearIndex: 0 });
  }
} catch (error) {
  console.error(`Stopped safely: ${error.message}`);
  process.exitCode = 1;
} finally {
  await context.close();
}

async function configureTractorMakerReport(page) {
  await page.locator("#j_idt29_input").selectOption("A");
  await page.locator("#yaxisVar_input").selectOption("Maker");
  await page.locator("#xaxisVar_input").selectOption("Calendar Year");
  await page.locator("#selectedYearType_input").selectOption("C");
  await page.locator("#vchgroupTable\\:selectCatgGrp_input").selectOption({ label: "TRACTOR" });
}

async function extractAllPages(page) {
  const all = [];
  while (true) {
    const rows = await page.locator("table").evaluateAll(tables => {
      const candidates = tables.filter(t =>
        t.rows.length > 4 && [...t.querySelectorAll("th")].some(h => h.textContent.trim() === "Maker")
      );
      const table = candidates[candidates.length - 1];
      return table ? [...table.querySelectorAll("tbody tr")].map(r =>
        [...r.querySelectorAll("td")].map(c => c.textContent.trim())
      ) : [];
    });
    all.push(...rows);
    const next = page.getByRole("link", { name: "Next Page", exact: true });
    if (await next.count() !== 1) break;
    const disabled = await next.getAttribute("class");
    if ((disabled || "").includes("ui-state-disabled")) break;
    await next.click();
    await page.waitForTimeout(800);
    await assertSafePage(page);
  }
  if (!all.length) throw new Error("No result rows found; dashboard layout or filters changed.");
  return all;
}

async function assertSafePage(page) {
  const status = await page.evaluate(() => ({
    title: document.title,
    text: document.body.innerText.slice(0, 12_000).toLowerCase()
  }));
  if (/captcha|verify you are human|access denied/.test(status.text)) {
    throw new Error("CAPTCHA or access challenge detected. No bypass attempted.");
  }
  if (/too many requests|rate limit|temporarily blocked/.test(status.text)) {
    throw new Error("Rate-limit response detected.");
  }
  if (!/vahan/.test((status.title || "").toLowerCase())) {
    throw new Error("Unexpected page; collection paused.");
  }
}

async function selectOptions(page, selector, excludedValue) {
  return page.locator(selector).evaluate((select, excluded) =>
    [...select.options]
      .filter(o => o.value && o.value !== excluded)
      .map(o => ({ value: o.value, text: o.textContent.trim() })),
  excludedValue);
}

async function randomizedPause() {
  const ms = MIN_DELAY + Math.floor(Math.random() * (MAX_DELAY - MIN_DELAY + 1));
  await new Promise(resolve => setTimeout(resolve, ms));
}

function enforceDailyLimit(usage) {
  if (usage.count >= DAILY_LIMIT) {
    throw new Error(`Daily safety limit (${DAILY_LIMIT}) reached. Resume tomorrow.`);
  }
}

async function loadUsage() {
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
  const saved = await readJson(USAGE_PATH, { date: today, count: 0 });
  return saved.date === today ? saved : { date: today, count: 0 };
}

async function saveCheckpoint(value) {
  await fs.writeFile(CHECKPOINT_PATH, JSON.stringify(value, null, 2));
}

async function ensureCsv() {
  try { await fs.access(CSV_PATH); }
  catch { await fs.writeFile(CSV_PATH, CSV_HEADERS.join(",") + "\n"); }
}

async function appendCsv(records) {
  const lines = records.map(r => CSV_HEADERS.map(h => csv(r[h])).join(",")).join("\n");
  if (lines) await fs.appendFile(CSV_PATH, lines + "\n");
}

function csv(value) {
  const text = String(value ?? "");
  return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function number(text) {
  return Number(String(text ?? "0").replaceAll(",", "")) || 0;
}

function integerEnv(name, fallback) {
  const value = Number.parseInt(process.env[name] || "", 10);
  return Number.isFinite(value) ? value : fallback;
}

async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch { return fallback; }
}
