import test from 'node:test';
import assert from 'node:assert/strict';
import { enumeratePeriods, estimateJob, MAX_OUTPUT_ROWS } from '../src/estimator.mjs';

test('enumerates an inclusive month range across years', () => {
  const periods = enumeratePeriods({ periodMode: 'month', startYear: 2025, startPeriod: 11, endYear: 2026, endPeriod: 2 });
  assert.deepEqual(periods.map((p) => p.label), ['Nov 2025','Dec 2025','Jan 2026','Feb 2026']);
});

test('all-RTO tractor totals for five years stay below the row ceiling', () => {
  const result = estimateJob({ segments:['TR'],states:['ALL'],breakdown:'total',periodMode:'month',startYear:2022,startPeriod:1,endYear:2026,endPeriod:12,output:'xlsx',consent:true });
  assert.equal(result.rtoCount, 1465);
  assert.equal(result.reportingUnits, 1465);
  assert.equal(result.estimatedRows, 87_900);
  assert.equal(result.allowed, true);
});

test('large maker detail jobs are rejected before collection', () => {
  const result = estimateJob({ segments:['TR'],states:['ALL'],breakdown:'maker',periodMode:'month',startYear:2026,startPeriod:1,endYear:2026,endPeriod:12,output:'xlsx',consent:true });
  assert.ok(result.estimatedRows > MAX_OUTPUT_ROWS);
  assert.equal(result.allowed, false);
  assert.match(result.errors.join(' '), /hard limit/);
});

test('PDF detail is capped at 2,000 estimated rows', () => {
  const result = estimateJob({ segments:['TR'],states:['DL'],breakdown:'total',periodMode:'month',startYear:2025,startPeriod:1,endYear:2026,endPeriod:12,output:'pdf',consent:true });
  assert.equal(result.estimatedRows, 384);
  assert.equal(result.allowed, true);
});

test('untrusted configuration values are normalized or rejected', () => {
  const result = estimateJob({ segments:['NOT_REAL'],states:['XX'],breakdown:'prototype',periodMode:'month',startYear:'not-a-year',startPeriod:999,endYear:2026,endPeriod:-5,output:'exe',browser:'unknown',rtoMode:'unknown',minDelaySeconds:-1,maxDelaySeconds:999,maxDailyReports:999,consent:true });
  assert.equal(result.allowed, false);
  assert.equal(result.config.browser, 'edge');
  assert.equal(result.config.background, true);
  assert.equal(result.config.breakdown, 'total');
  assert.equal(result.config.output, 'xlsx');
  assert.equal(result.config.rtoMode, 'rto_detail');
  assert.equal(result.config.minDelaySeconds, 30);
  assert.equal(result.config.maxDelaySeconds, 75);
  assert.equal(result.config.maxDailyReports, 100);
  assert.deepEqual(result.config.segments, []);
  assert.deepEqual(result.config.states, []);
});

test('state-total mode reduces reporting units without hiding the RTO scope', () => {
  const result = estimateJob({ segments:['TR'],states:['ALL'],rtoMode:'state_total',breakdown:'total',periodMode:'month',startYear:2026,startPeriod:1,endYear:2026,endPeriod:12,output:'xlsx',minDelaySeconds:30,maxDelaySeconds:45,maxDailyReports:100,consent:true });
  assert.equal(result.rtoCount, 1465);
  assert.equal(result.reportingUnits, 36);
  assert.equal(result.reportRequests, 36);
  assert.equal(result.estimatedRows, 432);
  assert.equal(result.estimatedActiveSeconds, 1638);
  assert.equal(result.allowed, true);
});

test('Chrome visible mode is explicit while background remains the default', () => {
  const background = estimateJob({ segments:['TR'],states:['CH'],startYear:2026,startPeriod:1,endYear:2026,endPeriod:1,consent:true });
  const visibleChrome = estimateJob({ segments:['TR'],states:['CH'],startYear:2026,startPeriod:1,endYear:2026,endPeriod:1,browser:'chrome',background:false,consent:true });
  assert.equal(background.config.background, true);
  assert.equal(background.config.browser, 'edge');
  assert.equal(visibleChrome.config.background, false);
  assert.equal(visibleChrome.config.browser, 'chrome');
});
