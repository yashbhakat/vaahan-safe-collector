const $ = (selector) => document.querySelector(selector);
const api = async (url, options = {}) => { const response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', 'X-Collector-Token': sessionToken, ...(options.headers || {}) } }); const value = await response.json().catch(() => ({})); if (!response.ok) throw new Error(value.error || `Request failed (${response.status})`); return value; };
let options; let latestEstimate; let timer; let sessionToken = '';

boot().catch((error) => { $('#form-error').textContent = error.message; });

async function boot() {
  const sessionResponse = await fetch('/api/session', { cache: 'no-store' });
  if (!sessionResponse.ok) throw new Error('The secure local session could not be established. Restart the collector.');
  sessionToken = (await sessionResponse.json()).token;
  options = await api('/api/options');
  renderOptions(); bind(); updatePeriods(); await recalculate(); await refreshJobs();
  setInterval(refreshJobs, 5000);
}

function renderOptions() {
  $('#segments').innerHTML = options.segments.map((s) => `<label class="choice"><input type="checkbox" name="segment" value="${s.id}" ${s.id === 'TR' ? 'checked' : ''}><span>${s.label}</span></label>`).join('');
  $('#breakdown').innerHTML = options.breakdowns.map((b) => `<option value="${b.id}">${b.label}</option>`).join('');
  $('#states').innerHTML = options.states.map((s) => `<label><input type="checkbox" name="state" value="${s.code}"><span>${s.name} (${s.rtos})</span></label>`).join('');
  const year = new Date().getFullYear();
  const years = Array.from({ length: 16 }, (_, i) => year - i).map((y) => `<option value="${y}">${y}</option>`).join('');
  $('#start-year').innerHTML = years; $('#end-year').innerHTML = years;
  const month = new Date().getMonth() + 1;
  const end = new Date(year, month - 1, 0);
  const start = new Date(end.getFullYear(), end.getMonth() - 11, 1);
  $('#start-year').value = String(start.getFullYear()); $('#end-year').value = String(end.getFullYear());
  $('#start-year').dataset.pendingPeriod = String(start.getMonth() + 1); $('#end-year').dataset.pendingPeriod = String(end.getMonth() + 1);
}

function bind() {
  $('#job-form').addEventListener('change', (event) => { if (event.target.id === 'period-mode') updatePeriods(); if (event.target.id === 'all-states') { $('#state-details').open = !event.target.checked; } if (event.target.id === 'speed-preset') applySpeedPreset(); clearTimeout(timer); timer = setTimeout(recalculate, 120); });
  $('#job-form').addEventListener('submit', startJob); $('#refresh-jobs').addEventListener('click', refreshJobs); $('#import-config').addEventListener('change', importConfig);
  $('#job-list').addEventListener('click', async (event) => {
    const exportButton = event.target.closest('[data-export]');
    if (exportButton) { exportButton.disabled = true; try { await downloadExport(exportButton.dataset.job, exportButton.dataset.export); } finally { exportButton.disabled = false; } return; }
    const button = event.target.closest('[data-stop],[data-resume]'); if (!button) return; button.disabled = true; const action = button.dataset.stop ? 'stop' : 'resume'; const id = button.dataset.stop || button.dataset.resume; await api(`/api/jobs/${id}/${action}`, { method: 'POST', body: '{}' }); await refreshJobs();
  });
}

async function importConfig(event) {
  const file = event.target.files?.[0]; if (!file) return;
  try {
    const imported = JSON.parse(await file.text());
    document.querySelectorAll('[name=segment]').forEach((el) => { el.checked = (imported.segments || []).includes(el.value); });
    const all = (imported.states || []).includes('ALL'); $('#all-states').checked = all; $('#state-details').open = !all;
    document.querySelectorAll('[name=state]').forEach((el) => { el.checked = !all && (imported.states || []).includes(el.value); });
    if (imported.breakdown) $('#breakdown').value = imported.breakdown;
    if (imported.periodMode) $('#period-mode').value = imported.periodMode; updatePeriods();
    const mapping = {startYear:'#start-year',startPeriod:'#start-period',endYear:'#end-year',endPeriod:'#end-period'};
    for (const [key,id] of Object.entries(mapping)) if (imported[key] != null) $(id).value = String(imported[key]);
    if (imported.output) $('#output').value = imported.output;
    if (imported.browser) $('#browser').value = imported.browser;
    if (imported.rtoMode) $('#rto-mode').value = imported.rtoMode;
    if (typeof imported.background === 'boolean') $('#run-mode').value = imported.background ? 'background' : 'visible';
    if (imported.minDelaySeconds) $('#delay').value = String(imported.minDelaySeconds);
    if (imported.maxDelaySeconds) $('#max-delay').value = String(imported.maxDelaySeconds);
    if (imported.maxDailyReports) $('#daily-limit').value = String(imported.maxDailyReports);
    $('#consent').checked = imported.consent === true; $('#form-error').textContent = ''; await recalculate();
  } catch (error) { $('#form-error').textContent = `Could not import plan: ${error.message}`; }
  finally { event.target.value = ''; }
}

function applySpeedPreset() {
  const balanced = $('#speed-preset').value === 'balanced';
  $('#delay').value = balanced ? '30' : '45';
  $('#max-delay').value = balanced ? '45' : '75';
  $('#daily-limit').value = balanced ? '100' : '80';
}

function updatePeriods() {
  const quarter = $('#period-mode').value === 'quarter';
  const labels = quarter ? ['Q1','Q2','Q3','Q4'] : ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  for (const id of ['start-period','end-period']) { const periodSelect = $(`#${id}`); const selected = $(id === 'start-period' ? '#start-year' : '#end-year').dataset.pendingPeriod || periodSelect.value || '1'; periodSelect.innerHTML = labels.map((l,i)=>`<option value="${i+1}">${l}</option>`).join(''); periodSelect.value = String(Math.min(labels.length, Number(selected))); }
}

function config() {
  const all = $('#all-states').checked;
  return {
    segments: [...document.querySelectorAll('[name=segment]:checked')].map((el) => el.value),
    states: all ? ['ALL'] : [...document.querySelectorAll('[name=state]:checked')].map((el) => el.value),
    breakdown: $('#breakdown').value, periodMode: $('#period-mode').value,
    startYear: Number($('#start-year').value), startPeriod: Number($('#start-period').value),
    endYear: Number($('#end-year').value), endPeriod: Number($('#end-period').value),
    output: $('#output').value, browser: $('#browser').value, background: $('#run-mode').value === 'background', rtoMode: $('#rto-mode').value, minDelaySeconds: Number($('#delay').value), maxDelaySeconds: Number($('#max-delay').value), maxDailyReports: Number($('#daily-limit').value), consent: $('#consent').checked,
  };
}

async function recalculate() {
  latestEstimate = await api('/api/estimate', { method: 'POST', body: JSON.stringify(config()) });
  const blocked = latestEstimate.errors.filter((e) => !e.startsWith('Confirm that'));
  const pct = Math.min(100, Math.round(latestEstimate.estimatedRows / options.limits.maxRows * 100));
  $('#estimate').innerHTML = `<div class="metric"><strong>${format(latestEstimate.estimatedRows)}</strong><small>estimated rows<br>${pct}% of hard limit</small></div>
    <div class="metric"><strong>${format(latestEstimate.reportingUnits)}</strong><small>reporting units<br>${format(latestEstimate.rtoCount)} RTOs in scope</small></div><div class="metric"><strong>${format(latestEstimate.reportRequests)}</strong><small>dashboard reports</small></div>
    <div class="metric"><strong>${latestEstimate.estimatedDays}</strong><small>minimum collection days<br>≈ ${latestEstimate.estimatedActiveHours} active hours</small></div>
    ${blocked.length ? `<div class="warning blocked">${blocked.map(escapeHtml).join('<br>')}</div>` : `<div class="warning">Estimate is conservative. Actual dashboard categories and RTO availability can change.</div>`}`;
  $('#start-job').disabled = !latestEstimate.allowed;
  $('#form-error').textContent = '';
}

async function startJob(event) {
  event.preventDefault(); const button = $('#start-job'); button.disabled = true; button.textContent = 'Starting safely…';
  try { const job = await api('/api/jobs', { method: 'POST', body: JSON.stringify(config()) }); await refreshJobs(); document.querySelector('#jobs').scrollIntoView(); }
  catch (error) { $('#form-error').textContent = error.message; }
  finally { button.textContent = 'Start secure background collection'; await recalculate(); }
}

async function refreshJobs() {
  const jobs = await api('/api/jobs');
  $('#job-list').innerHTML = jobs.length ? jobs.map(jobCard).join('') : '<p class="empty">No collection jobs yet.</p>';
}
function jobCard(job) {
  const reports = job.estimate?.reportRequests || 0; const pct = reports ? Math.min(100, Math.round(job.completedReports / reports * 100)) : 0;
  const canStop = ['starting','running','waiting'].includes(job.status);
  const canResume = ['paused','stopped'].includes(job.status);
  return `<article class="job-card"><div><span class="status ${job.status}">${job.status}</span><h3>${job.id}</h3><div class="job-meta">${escapeHtml(job.current || '')}<br>${format(job.collectedRows)} rows · ${format(job.completedReports)} / ${format(reports)} reports (${pct}%)${job.error ? `<br><b>${escapeHtml(job.error)}</b>` : ''}</div></div>
    <div class="job-actions">${canStop ? `<button data-stop="${job.id}">Stop safely</button>` : ''}${canResume ? `<button data-resume="${job.id}">Resume checkpoint</button>` : ''}<button class="download" data-job="${job.id}" data-export="xlsx">Download XLSX</button><button data-job="${job.id}" data-export="csv">Download CSV</button>${job.collectedRows <= 2000 ? `<button data-job="${job.id}" data-export="pdf">Download PDF</button>` : ''}</div></article>`;
}
async function downloadExport(jobId, format) {
  const response = await fetch(`/api/jobs/${jobId}/export?format=${format}`, { headers: { 'X-Collector-Token': sessionToken } });
  if (!response.ok) { const value = await response.json().catch(() => ({})); throw new Error(value.error || 'Export failed'); }
  const blob = await response.blob(); const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = `vaahan-${jobId}.${format}`; anchor.click(); URL.revokeObjectURL(url);
}
function format(value) { return Number(value || 0).toLocaleString('en-IN'); }
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
