import { BREAKDOWNS, MONTHS, STATE_COUNTS, VEHICLE_SEGMENTS } from './catalog.mjs';

export const MAX_OUTPUT_ROWS = 100_000;
export const MAX_DAILY_REPORTS = 100;
export const MIN_DELAY_SECONDS = 30;
export const EXPECTED_REFRESH_SECONDS = 8;

const CURRENT_YEAR = new Date().getFullYear();
const MIN_YEAR = 2000;

function integer(value, fallback, min, max) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(max, Math.max(min, Math.trunc(number))) : fallback;
}

export function normalizeConfig(input = {}) {
  const periodMode = input.periodMode === 'quarter' ? 'quarter' : 'month';
  const maxPeriod = periodMode === 'quarter' ? 4 : 12;
  const validSegments = new Set(VEHICLE_SEGMENTS.map((item) => item.id));
  const validStates = new Set(STATE_COUNTS.map((item) => item.code));
  const segments = [...new Set(Array.isArray(input.segments) ? input.segments.filter((value) => typeof value === 'string' && validSegments.has(value)) : [])];
  const states = [...new Set(Array.isArray(input.states) ? input.states.filter((value) => value === 'ALL' || (typeof value === 'string' && validStates.has(value))) : [])];
  const breakdown = BREAKDOWNS.some((item) => item.id === input.breakdown) ? input.breakdown : 'total';
  const minDelaySeconds = integer(input.minDelaySeconds, MIN_DELAY_SECONDS, MIN_DELAY_SECONDS, 300);
  return {
    segments,
    states,
    breakdown,
    periodMode,
    startYear: integer(input.startYear, CURRENT_YEAR - 1, MIN_YEAR, CURRENT_YEAR),
    startPeriod: integer(input.startPeriod, 1, 1, maxPeriod),
    endYear: integer(input.endYear, CURRENT_YEAR, MIN_YEAR, CURRENT_YEAR),
    endPeriod: integer(input.endPeriod, maxPeriod, 1, maxPeriod),
    output: ['xlsx', 'csv', 'pdf'].includes(input.output) ? input.output : 'xlsx',
    browser: input.browser === 'chrome' ? 'chrome' : 'edge',
    background: input.background !== false,
    rtoMode: input.rtoMode === 'state_total' ? 'state_total' : 'rto_detail',
    minDelaySeconds,
    maxDelaySeconds: integer(input.maxDelaySeconds, minDelaySeconds + 15, minDelaySeconds, Math.min(300, minDelaySeconds + 45)),
    maxDailyReports: integer(input.maxDailyReports, MAX_DAILY_REPORTS, 1, MAX_DAILY_REPORTS),
    consent: input.consent === true,
  };
}

export function enumeratePeriods(config) {
  const c = normalizeConfig(config);
  const maxPeriod = c.periodMode === 'quarter' ? 4 : 12;
  const start = c.startYear * maxPeriod + Math.min(maxPeriod, Math.max(1, c.startPeriod)) - 1;
  const end = c.endYear * maxPeriod + Math.min(maxPeriod, Math.max(1, c.endPeriod)) - 1;
  if (end < start) return [];
  const result = [];
  for (let cursor = start; cursor <= end; cursor += 1) {
    const year = Math.floor(cursor / maxPeriod);
    const period = cursor % maxPeriod + 1;
    result.push({ year, period, label: c.periodMode === 'quarter' ? `${year} Q${period}` : `${MONTHS[period - 1]} ${year}` });
  }
  return result;
}

export function estimateJob(input = {}) {
  const config = normalizeConfig(input);
  const segments = VEHICLE_SEGMENTS.filter((item) => config.segments.includes(item.id));
  const states = config.states.includes('ALL') ? STATE_COUNTS : STATE_COUNTS.filter((item) => config.states.includes(item.code));
  const breakdown = BREAKDOWNS.find((item) => item.id === config.breakdown) || BREAKDOWNS[0];
  const periods = enumeratePeriods(config);
  const rtoCount = states.reduce((sum, item) => sum + item.rtos, 0);
  const reportingUnits = config.rtoMode === 'state_total' ? states.length : rtoCount;
  const dimensionCount = breakdown.id === 'vehicle_class'
    ? Math.max(1, ...segments.map((item) => item.classes))
    : breakdown.count;
  const estimatedRows = reportingUnits * periods.length * segments.length * dimensionCount;
  const distinctYears = new Set(periods.map((item) => item.year)).size;
  const reportRequests = reportingUnits * distinctYears * segments.length;
  const estimatedDays = Math.max(1, Math.ceil(reportRequests / config.maxDailyReports));
  const averageDelaySeconds = (config.minDelaySeconds + config.maxDelaySeconds) / 2;
  const estimatedPacingHours = Number(((reportRequests * averageDelaySeconds) / 3600).toFixed(1));
  const estimatedActiveSeconds = Math.round(reportRequests * (averageDelaySeconds + EXPECTED_REFRESH_SECONDS));
  const estimatedActiveHours = Number((estimatedActiveSeconds / 3600).toFixed(1));
  const errors = [];
  if (!segments.length) errors.push('Select at least one vehicle segment.');
  if (!states.length) errors.push('Select at least one state or All India.');
  if (!periods.length) errors.push('The end of the timeline must be after its start.');
  if (estimatedRows > MAX_OUTPUT_ROWS) errors.push(`Estimated output is ${estimatedRows.toLocaleString('en-IN')} rows; the hard limit is ${MAX_OUTPUT_ROWS.toLocaleString('en-IN')}. Narrow the scope.`);
  if (config.output === 'pdf' && estimatedRows > 2_000) errors.push('PDF is limited to 2,000 detailed rows. Choose XLSX/CSV or narrow the scope.');
  if (!config.consent) errors.push('Confirm that you will use the public aggregate data responsibly and stop if Vaahan requests it.');
  return {
    config, segments, states, breakdown, periods, rtoCount, reportingUnits, dimensionCount,
    estimatedRows, reportRequests, estimatedDays, estimatedPacingHours, estimatedActiveSeconds, estimatedActiveHours,
    allowed: errors.length === 0, errors,
  };
}
