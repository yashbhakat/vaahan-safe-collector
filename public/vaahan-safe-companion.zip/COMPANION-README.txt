VAAHAN SAFE DATA COLLECTOR — WINDOWS COMPANION

This local companion is required because a public static website cannot safely
run a persistent Chrome or Edge browser on a visitor's computer.

Requirements
- Windows 10 or 11
- Node.js 20 or newer from https://nodejs.org/
- Microsoft Edge or Google Chrome installed
- Optional for PDF export: Python 3 with the reportlab package

Setup
1. Extract the entire ZIP to a normal folder.
2. Right-click install.ps1 and choose Run with PowerShell. This installs the
   exact dependency versions recorded in package-lock.json and skips browser
   downloads; your installed Edge or Chrome is used.
3. Run start.ps1 and leave the PowerShell window open.
4. Open https://yashbhakat.github.io/vaahan-safe-collector/ and allow local
   network access if the browser asks.

Security design
- The service listens only on 127.0.0.1 and is not exposed to the internet.
- A random session token is created on every restart.
- Only the published planner and the same-origin local control room are allowed.
- Mutating requests require JSON, the session token, and pass a local rate limit.
- One scrape job can run at a time. CAPTCHA or access challenges pause the job.
- No passwords, vehicle-level records, proxies, CAPTCHA solving, or bypasses.

Background collection
Vaahan rejects true headless browser access. To respect that control, background
mode uses a normal browser minimized to the taskbar; it may briefly appear while
starting. Choose Visible troubleshooting only when you need to observe an issue.
Closing start.ps1 stops the companion; completed data and checkpoints remain in
the local data folder.

This independent project is for educational, research, and analytical use. It
is not affiliated with or endorsed by MoRTH, NIC, Parivahan, or Vaahan. Users
must comply with current site terms, access controls, and applicable law.
