export const SOURCE_URL = 'https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml';

export const VEHICLE_SEGMENTS = [
  { id: '2W', label: 'Two wheelers', group: '2W|1,2,3,4,5,51,52,53|2WIC,2WN,2WT', classes: 8 },
  { id: '3W', label: 'Three wheelers', group: '3W|6,54,55,57,58|3WN,3WT', classes: 5 },
  { id: '4W', label: 'Four wheelers', group: '4W|5,7,15,23,31,56,70,71,93|4WIC,LMV,MMV,HMV', classes: 9 },
  { id: 'AH', label: 'Adapted / special vehicles', group: 'AH|76,77,85|2WT,LPV,MPV,HPV,LGV,MGV,HGV', classes: 3 },
  { id: 'CE', label: 'Construction equipment', group: 'CE|22,25,26,29,87,88,92|LMV,MMV,HMV,LGV,MGV,HGV,OTH', classes: 7 },
  { id: 'GV', label: 'Goods vehicles', group: 'GV|59,64,79,84|LGV,MGV,HGV', classes: 4 },
  { id: 'PS', label: 'Passenger vehicles', group: 'PS|69,73,75,78,86|LPV,MPV,HPV', classes: 5 },
  { id: 'SC', label: 'Special categories', group: 'SC|8,9,10,11,12,14,17,18,19,20,21,24,27,32,62,65,66,67,68,80,81,83|LMV,MMV,HMV,LGV,MGV,HGV,OTH', classes: 22 },
  { id: 'TL', label: 'Trailers', group: 'TL|16,28,30,82,89,91,94|LMV,HMV,MMV,LGV,MGV,HGV', classes: 7 },
  { id: 'TR', label: 'Tractors', group: 'TR|13,63,90|LMV,MMV,LGV,MGV,HGV,OTH', classes: 3 },
];

export const BREAKDOWNS = [
  { id: 'total', label: 'Total registrations', count: 1, yAxis: 'Vehicle Category' },
  { id: 'vehicle_class', label: 'Vehicle class', count: null, yAxis: 'Vehicle Class' },
  { id: 'maker', label: 'Maker / manufacturer', count: 250, yAxis: 'Maker' },
  { id: 'fuel', label: 'Fuel', count: 36, yAxis: 'Fuel' },
  { id: 'norms', label: 'Emission norms', count: 26, yAxis: 'Norms' },
  { id: 'vehicle_category', label: 'Vehicle category', count: 8, yAxis: 'Vehicle Category' },
];

export const STATE_COUNTS = [
  ['AN','Andaman & Nicobar Islands',5],['AP','Andhra Pradesh',84],['AR','Arunachal Pradesh',29],
  ['AS','Assam',35],['BR','Bihar',48],['CG','Chhattisgarh',31],['CH','Chandigarh',1],
  ['DD','Dadra & Nagar Haveli and Daman & Diu',3],['DL','Delhi',16],['GA','Goa',13],
  ['GJ','Gujarat',38],['HP','Himachal Pradesh',98],['HR','Haryana',104],['JH','Jharkhand',25],
  ['JK','Jammu & Kashmir',21],['KA','Karnataka',68],['KL','Kerala',87],['LA','Ladakh',3],
  ['LD','Lakshadweep',9],['MH','Maharashtra',59],['ML','Meghalaya',14],['MN','Manipur',17],
  ['MP','Madhya Pradesh',53],['MZ','Mizoram',12],['NL','Nagaland',9],['OR','Odisha',39],
  ['PB','Punjab',96],['PY','Puducherry',8],['RJ','Rajasthan',60],['SK','Sikkim',9],
  ['TG','Telangana',57],['TN','Tamil Nadu',148],['TR','Tripura',9],['UK','Uttarakhand',21],
  ['UP','Uttar Pradesh',77],['WB','West Bengal',59],
].map(([code, name, rtos]) => ({ code, name, rtos }));

export const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
